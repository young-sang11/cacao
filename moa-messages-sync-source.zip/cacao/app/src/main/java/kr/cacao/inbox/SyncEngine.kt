package kr.cacao.inbox

import android.content.Context
import android.net.Uri
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.work.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URL
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager

internal data class PairConfig(val urls: List<String>, val secret: String, val fingerprint: String) {
    fun json() = JSONObject().put("version", 1).put("urls", JSONArray(urls)).put("secret", secret).put("fingerprint", fingerprint)
    companion object {
        fun parse(link: String): PairConfig {
            val uri = Uri.parse(link.trim())
            require(uri.scheme == "moainbox" && uri.host == "pair")
            val json = JSONObject(String(Base64.decode(uri.getQueryParameter("data"), Base64.URL_SAFE or Base64.NO_WRAP), Charsets.UTF_8))
            return fromJson(json)
        }
        fun fromJson(json: JSONObject): PairConfig {
            require(json.getInt("version") == 1)
            val urls = json.getJSONArray("urls").let { a -> (0 until a.length()).map { a.getString(it) } }
            require(urls.isNotEmpty() && urls.size <= 16)
            urls.forEach { value ->
                val u = URL(value)
                require(u.protocol == "https" && u.host.isNotBlank() && u.userInfo == null && u.query == null && u.ref == null && u.path in listOf("", "/"))
            }
            val secret = json.getString("secret").lowercase()
            val fingerprint = json.getString("fingerprint").lowercase()
            require(secret.matches(Regex("[0-9a-f]{64}")) && fingerprint.matches(Regex("[0-9a-f]{64}")))
            return PairConfig(urls.map { it.trimEnd('/') }, secret, fingerprint)
        }
    }
}

internal object SyncCrypto {
    fun digest(text: String) = MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8))
    fun hex(bytes: ByteArray) = bytes.joinToString("") { "%02x".format(it.toInt() and 255) }
    fun token(secret: String) = hex(digest("moa:auth:v1:$secret"))
    private fun key(secret: String) = SecretKeySpec(digest("moa:encryption:v1:$secret"), "AES")
    private fun b64(bytes: ByteArray) = Base64.encodeToString(bytes, Base64.NO_WRAP)
    fun encrypt(message: InboxMessage, secret: String): JSONObject {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key(secret), GCMParameterSpec(128, iv))
        cipher.updateAAD("moa:v1:${message.id}".toByteArray(Charsets.UTF_8))
        val payload = JSONObject().put("id", message.id).put("source", message.source)
            .put("sender", message.sender).put("conversation", message.conversation)
            .put("body", message.body).put("receivedAt", message.receivedAt).toString()
        return JSONObject().put("id", message.id).put("iv", b64(iv)).put("ciphertext", b64(cipher.doFinal(payload.toByteArray(Charsets.UTF_8))))
            .put("checked", message.checked).put("deleted", false)
    }
    fun decrypt(item: JSONObject, secret: String): InboxMessage {
        val id = item.getString("id")
        require(id.matches(Regex("[a-f0-9]{64}")))
        val iv = Base64.decode(item.getString("iv"), Base64.NO_WRAP)
        require(iv.size == 12 && item.getString("ciphertext").length <= 131072)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(secret), GCMParameterSpec(128, iv))
        cipher.updateAAD("moa:v1:$id".toByteArray(Charsets.UTF_8))
        val json = JSONObject(String(cipher.doFinal(Base64.decode(item.getString("ciphertext"), Base64.NO_WRAP)), Charsets.UTF_8))
        require(json.getString("id") == id)
        val sender = json.getString("sender"); val body = json.getString("body"); val conversation = json.getString("conversation")
        val source = json.getString("source")
        require(sender.length <= 1000 && conversation.length <= 1000 && body.length <= 32000 && source in listOf("KAKAO", "IMPORT"))
        return InboxMessage(id, "", conversation, sender, body, json.getLong("receivedAt"), item.getBoolean("checked"), source)
    }
}

internal object SyncPrefs {
    private fun prefs(context: Context) = context.getSharedPreferences("sync-connection", Context.MODE_PRIVATE)
    fun isEnabled(context: Context) = prefs(context).getBoolean("enabled", false)
    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey("moa-sync-config", null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder("moa-sync-config", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        }.generateKey()
    }
    fun save(context: Context, config: PairConfig) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key()) }
        val encrypted = cipher.doFinal(config.json().toString().toByteArray(Charsets.UTF_8))
        check(prefs(context).edit().putString("data", Base64.encodeToString(cipher.iv + encrypted, Base64.NO_WRAP)).putBoolean("enabled", true).putString("binding", SyncCrypto.token(config.secret)).commit())
    }
    fun matches(context: Context, config: PairConfig) = isEnabled(context) && prefs(context).getString("binding", null) == SyncCrypto.token(config.secret)
    fun load(context: Context): PairConfig? {
        if (!isEnabled(context)) return null
        val encoded = prefs(context).getString("data", null) ?: return null
        val bytes = Base64.decode(encoded, Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, bytes.copyOfRange(0, 12))) }
        return PairConfig.fromJson(JSONObject(String(cipher.doFinal(bytes.copyOfRange(12, bytes.size)), Charsets.UTF_8)))
    }
    fun disable(context: Context) { check(prefs(context).edit().clear().commit()) }
}

internal data class SyncSnapshot(val messages: List<InboxMessage>, val deleted: List<String>, val cursor: Long, val instance: String?)
internal data class SyncIncoming(val id: String, val deleted: Boolean, val checked: Boolean, val message: InboxMessage?)

internal object SyncEngine {
    val status = MutableStateFlow("PC 동기화 꺼짐")
    private val mutex = Mutex()
    suspend fun run(context: Context): Boolean = withContext(Dispatchers.IO) {
        mutex.withLock {
            try {
                val config = SyncPrefs.load(context) ?: return@withLock true
                val store = (context.applicationContext as InboxApplication).store
                status.value = "PC 연결 확인 중"
                val snapshot = store.syncSnapshot()
                val items = snapshot.messages.map { SyncCrypto.encrypt(it, config.secret) } + snapshot.deleted.map {
                    JSONObject().put("id", it).put("deleted", true).put("checked", false)
                }
                var base: String? = null
                var instance: String? = null
                for (url in config.urls) {
                    try { instance = request(context, config, url, "/api/changes?after=0").getString("instance"); base = url; break } catch (_: IOException) { }
                }
                val server = base ?: throw IOException("PC unavailable")
                for (batch in items.chunked(100)) request(context, config, server, "/api/messages", JSONObject().put("items", JSONArray(batch)))
                var cursor = if(snapshot.instance == instance) snapshot.cursor else 0L
                var more: Boolean
                do {
                    val page = request(context, config, server, "/api/changes?after=$cursor")
                    val array = page.getJSONArray("items")
                    require(array.length() <= 200)
                    val rows = (0 until array.length()).map { i ->
                        val item = array.getJSONObject(i)
                        val id = item.getString("id")
                        require(id.matches(Regex("[0-9a-f]{64}")))
                        val deleted = item.getBoolean("deleted")
                        SyncIncoming(id, deleted, item.getBoolean("checked"), if(deleted) null else SyncCrypto.decrypt(item, config.secret))
                    }
                    check(SyncPrefs.matches(context, config))
                    val nextCursor = page.getLong("cursor")
                    require(nextCursor >= cursor)
                    require(page.getString("instance") == instance)
                    store.applySync(rows, nextCursor, requireNotNull(instance))
                    cursor = nextCursor; more = page.getBoolean("more")
                } while(more)
                status.value = "PC 동기화 완료"
                true
            } catch (_: Exception) {
                status.value = if(SyncPrefs.isEnabled(context)) "동기화 대기 · PC 실행, 같은 Wi-Fi와 저장 공간을 확인해 주세요" else "PC 동기화 꺼짐"
                false
            }
        }
    }
    private fun request(context: Context, config: PairConfig, base: String, route: String, body: JSONObject? = null): JSONObject {
        check(SyncPrefs.matches(context, config))
        val manager = object : X509TrustManager {
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) { throw java.security.cert.CertificateException("Client certificates not used") }
            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {
                val cert = chain.firstOrNull() ?: throw java.security.cert.CertificateException("Missing certificate")
                cert.checkValidity()
                val actual = MessageDigest.getInstance("SHA-256").digest(cert.encoded)
                val expected = config.fingerprint.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
                if(!MessageDigest.isEqual(actual, expected)) throw java.security.cert.CertificateException("Paired certificate mismatch")
            }
        }
        val tls = SSLContext.getInstance("TLS").apply { init(null, arrayOf(manager), SecureRandom()) }
        val connection = URL(base + route).openConnection() as HttpsURLConnection
        connection.sslSocketFactory = tls.socketFactory
        // Keep Android's default hostname/SAN validation in addition to certificate pinning.
        connection.connectTimeout = 4000; connection.readTimeout = 12000; connection.instanceFollowRedirects = false
        connection.setRequestProperty("Authorization", "Bearer ${SyncCrypto.token(config.secret)}")
        connection.setRequestProperty("Accept", "application/json")
        try {
            if(body != null) {
                connection.requestMethod = "POST"; connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json")
                val data = body.toString().toByteArray(Charsets.UTF_8)
                connection.setFixedLengthStreamingMode(data.size)
                connection.outputStream.use { it.write(data) }
            }
            if(connection.responseCode != 200) throw IOException("Sync request rejected")
            val data = connection.inputStream.use { input ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                while(true) {
                    val count = input.read(buffer)
                    if(count == -1) break
                    require(output.size() + count <= 32 * 1024 * 1024)
                    output.write(buffer, 0, count)
                }
                output.toByteArray()
            }
            require(data.size <= 32 * 1024 * 1024)
            return JSONObject(String(data, Charsets.UTF_8))
        } finally { connection.disconnect() }
    }
}

internal object SyncSchedule {
    fun configure(context: Context) {
        WorkManager.getInstance(context).enqueueUniquePeriodicWork("moa-sync-periodic", ExistingPeriodicWorkPolicy.UPDATE,
            PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES).setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build())
        soon(context)
    }
    fun soon(context: Context) {
        if(!SyncPrefs.isEnabled(context)) return
        WorkManager.getInstance(context).enqueueUniqueWork("moa-sync-now", ExistingWorkPolicy.KEEP,
            OneTimeWorkRequestBuilder<SyncWorker>().setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS).build())
    }
    fun stop(context: Context) {
        SyncPrefs.disable(context)
        WorkManager.getInstance(context).cancelUniqueWork("moa-sync-periodic")
        WorkManager.getInstance(context).cancelUniqueWork("moa-sync-now")
        SyncEngine.status.value = "PC 동기화 꺼짐"
    }
}

class SyncWorker(context: Context, parameters: WorkerParameters) : CoroutineWorker(context, parameters) {
    override suspend fun doWork(): Result = if(SyncEngine.run(applicationContext)) Result.success() else Result.retry()
}
