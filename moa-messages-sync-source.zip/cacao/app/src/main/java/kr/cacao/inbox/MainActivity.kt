package kr.cacao.inbox

import android.app.KeyguardManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    private var unlocked by mutableStateOf(false)
    private var hasAccess by mutableStateOf(false)
    private var incomingPair by mutableStateOf<String?>(null)
    private val store get() = (application as InboxApplication).store
    private val auth = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        unlocked = result.resultCode == RESULT_OK
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        receivePair(intent)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF245B49)),
                typography = Typography(bodyLarge = androidx.compose.ui.text.TextStyle(fontSize = 20.sp, lineHeight = 30.sp),
                    bodyMedium = androidx.compose.ui.text.TextStyle(fontSize = 18.sp, lineHeight = 26.sp),
                    labelLarge = androidx.compose.ui.text.TextStyle(fontSize = 18.sp))) {
                Surface(Modifier.fillMaxSize()) {
                    if (unlocked) InboxScreen(store, hasAccess, ::requestCollection, ::openOriginal, ::copyMessages, incomingPair) { incomingPair = null }
                    else LockScreen(::unlock)
                }
            }
        }
    }
    private fun receivePair(value: Intent?) {
        value?.data?.takeIf { it.scheme == "moainbox" && it.host == "pair" }?.let { incomingPair = it.toString() }
    }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); receivePair(intent) }
    override fun onResume() {
        super.onResume()
        hasAccess = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.split(':')?.any { ComponentName.unflattenFromString(it) == ComponentName(this, KakaoNotificationListener::class.java) } == true
    }
    override fun onStop() { unlocked = false; super.onStop() }
    @Suppress("DEPRECATION")
    private fun unlock() {
        val manager = getSystemService(KeyguardManager::class.java)
        if (!manager.isDeviceSecure) {
            Toast.makeText(this, "개인정보 보호를 위해 먼저 휴대전화 화면 잠금을 설정해 주세요.", Toast.LENGTH_LONG).show()
            safeStart(Intent(Settings.ACTION_SECURITY_SETTINGS))
            return
        }
        manager.createConfirmDeviceCredentialIntent("모아 메시지 잠금 해제", "저장한 메시지를 확인하려면 기기 잠금을 해제해 주세요.")
            ?.let { auth.launch(it) }
    }
    private fun requestCollection() {
        store.setEnabled(true)
        if (!hasAccess) safeStart(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        else android.service.notification.NotificationListenerService.requestRebind(ComponentName(this, KakaoNotificationListener::class.java))
    }
    private fun safeStart(intent: Intent) {
        try { startActivity(intent) } catch (_: android.content.ActivityNotFoundException) {
            Toast.makeText(this, "설정 화면을 열 수 없습니다. 휴대전화 설정에서 직접 열어 주세요.", Toast.LENGTH_LONG).show()
        }
    }
    private fun openOriginal(message: InboxMessage) {
        if(message.source != "KAKAO") {
            Toast.makeText(this, "PC에서 직접 가져온 내용입니다.", Toast.LENGTH_LONG).show()
            return
        }
        if (KakaoNotificationListener.openOriginal(message.notificationKey)) return
        val intent = packageManager.getLaunchIntentForPackage(MessageRules.KAKAO_PACKAGE)
        if (intent == null) Toast.makeText(this, "카카오톡 앱을 찾을 수 없습니다.", Toast.LENGTH_LONG).show()
        else {
            safeStart(intent)
            Toast.makeText(this, "카카오톡에서 해당 대화방을 선택해 주세요.", Toast.LENGTH_LONG).show()
        }
    }
    private fun copyMessages(messages: List<InboxMessage>) {
        val text = messages.joinToString("\n\n") { "[${sourceName(it)}] ${it.conversation}\n보낸 사람: ${it.sender}\n받은 시간: ${formatTime(it.receivedAt)}\n${it.body}" }
        val clip = ClipData.newPlainText("선택한 메시지", text)
        clip.description.extras = android.os.PersistableBundle().apply { putBoolean("android.content.extra.IS_SENSITIVE", true) }
        getSystemService(ClipboardManager::class.java).setPrimaryClip(clip)
        Toast.makeText(this, "${messages.size}개 메시지를 복사했습니다. 다른 앱에 붙여넣을 때 내용을 확인해 주세요.", Toast.LENGTH_LONG).show()
    }
}

private fun formatTime(time: Long): String = DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm")
    .withZone(ZoneId.systemDefault()).format(Instant.ofEpochMilli(time))

@Composable
private fun LockScreen(unlock: () -> Unit) {
    Column(Modifier.safeDrawingPadding().padding(24.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.Center) {
        Text("모아 메시지", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(24.dp))
        Text("카카오톡 알림을 한곳에서 확인하세요. PC 동기화는 직접 동의한 경우에만 사용합니다.")
        Spacer(Modifier.height(16.dp))
        Text("기기 화면 잠금이 필요합니다. 앱을 벗어나면 다시 잠깁니다.")
        Button(onClick = unlock, modifier = Modifier.fillMaxWidth().padding(top = 24.dp).heightIn(min = 56.dp)) { Text("잠금 해제") }
    }
}

@Composable
private fun InboxScreen(
    store: MessageStore, hasAccess: Boolean, enable: () -> Unit,
    openOriginal: (InboxMessage) -> Unit, copy: (List<InboxMessage>) -> Unit,
    incomingPair: String?, consumePair: () -> Unit,
) {
    val messages by store.messages.collectAsStateWithLifecycle()
    val error by store.error.collectAsStateWithLifecycle()
    val connected by KakaoNotificationListener.connected.collectAsStateWithLifecycle()
    var enabled by remember { mutableStateOf(store.enabled) }
    var consentDialog by remember { mutableStateOf(false) }
    var deleteDialog by remember { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var unreadOnly by rememberSaveable { mutableStateOf(false) }
    var byPerson by rememberSaveable { mutableStateOf(false) }
    var selection by remember { mutableStateOf(setOf<String>()) }
    var detailId by remember { mutableStateOf<String?>(null) }
    val filtered = messages.filter {
        (!unreadOnly || !it.checked) && (query.isBlank() ||
            listOf(it.sender, it.conversation, it.body, formatTime(it.receivedAt)).any { field -> field.contains(query, ignoreCase = true) })
    }.let { list -> if (byPerson) list.sortedWith(compareBy<InboxMessage> { it.sender }.thenByDescending { it.receivedAt }) else list }
    val selected = messages.filter { it.id in selection }
    Column(Modifier.safeDrawingPadding().fillMaxSize().padding(horizontal = 16.dp)) {
        Text("통합 메시지함", style = MaterialTheme.typography.headlineLarge, modifier = Modifier.padding(top = 16.dp))
        Text("미확인 ${messages.count { !it.checked }}개 · 전체 ${messages.size}개")
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(if (!enabled) "알림 수집 중지됨" else if (!hasAccess) "알림 접근 허용 필요" else if (!connected) "알림 수집 서비스 연결 대기 중" else "카카오톡 새 알림 수집 중")
                        Text("알림에 보인 내용만 저장합니다. 카카오톡 읽음 상태와 이 앱의 확인 상태는 별개입니다.")
                        if (!enabled || !hasAccess || !connected) Button(onClick = { consentDialog = true }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("알림 수집 설정") }
                        if (enabled) OutlinedButton(onClick = { store.setEnabled(false); enabled = false }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("수집 일시 중지") }
                    }
                }
            }
            item { SyncPanel(store, incomingPair, consumePair) }
            item {
                OutlinedTextField(query, { query = it }, label = { Text("사람·내용·날짜 검색") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    FilterChip(unreadOnly, { unreadOnly = !unreadOnly }, label = { Text("미확인만") })
                    FilterChip(byPerson, { byPerson = !byPerson }, label = { Text(if (byPerson) "사람순" else "최신 날짜순") })
                }
                if (selected.isNotEmpty()) {
                    Text("${selected.size}개 선택됨")
                    Button(onClick = { copy(selected) }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("선택 메시지 일괄 복사") }
                    OutlinedButton(onClick = { store.markChecked(selection); selection = emptySet() }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("선택 메시지 확인 완료") }
                    TextButton(onClick = { selection = emptySet() }) { Text("선택 해제") }
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
            if (filtered.isEmpty()) item {
                Text(if (messages.isEmpty()) "아직 수집한 메시지가 없습니다. 알림 수집을 허용한 뒤 새 카카오톡 알림을 받아 보세요. 기존 대화는 가져오지 않습니다." else "검색 조건에 맞는 메시지가 없습니다.", modifier = Modifier.padding(vertical = 24.dp))
            }
            items(filtered, key = { it.id }) { message ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row {
                            Checkbox(message.id in selection, { checked -> selection = if (checked) selection + message.id else selection - message.id },
                                modifier = Modifier.semantics { contentDescription = "${message.sender}의 ${formatTime(message.receivedAt)} 메시지 선택" })
                            Column(Modifier.weight(1f)) {
                                Text("${sourceName(message)} · ${if (message.checked) "확인 완료" else "미확인"}", color = MaterialTheme.colorScheme.primary)
                                Text(message.sender, style = MaterialTheme.typography.titleLarge)
                            }
                        }
                        if (message.conversation != message.sender) Text("대화: ${message.conversation}")
                        Text(formatTime(message.receivedAt))
                        Text(message.body, maxLines = 4, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                        Button(onClick = { detailId = message.id; store.markChecked(setOf(message.id)) }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("메시지 전체 보기") }
                    }
                }
            }
            item {
                Text("인증·비밀번호 관련 문구는 저장하지 않습니다. 자동 감지는 완벽하지 않으므로 공유·복사 전에 직접 확인해 주세요.")
                Text("SMS·첨부파일·ChatGPT·AI 답장·캘린더는 후속 단계에서 추가됩니다.")
                OutlinedButton(onClick = { deleteDialog = true }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("저장 자료 전체 삭제") }
            }
        }
    }
    if (consentDialog) AlertDialog(onDismissRequest = { consentDialog = false },
        title = { Text("알림 접근 권한 안내") },
        text = { Text("Android 알림 접근 권한은 다른 앱의 알림도 읽을 수 있는 권한입니다. 모아 메시지는 카카오톡 알림의 보낸 사람·시간·표시된 원문만 이 기기에 저장합니다. 파일이나 기존 대화는 읽지 않으며 외부 서버 전송·자동 답장을 하지 않습니다. 인증·비밀번호 문구는 저장에서 제외합니다. 언제든 수집을 중지하거나 자료를 삭제할 수 있습니다. 동의하면 설정에서 ‘모아 메시지’를 허용해 주세요.", modifier = Modifier.verticalScroll(rememberScrollState())) },
        confirmButton = { TextButton(onClick = { enable(); enabled = true; consentDialog = false }) { Text("동의하고 설정") } },
        dismissButton = { TextButton(onClick = { consentDialog = false }) { Text("취소") } })
    if (deleteDialog) AlertDialog(onDismissRequest = { deleteDialog = false },
        title = { Text("저장 자료를 모두 삭제할까요?") }, text = { Text("모아 메시지에 저장된 모든 메시지를 삭제하고 수집을 중지합니다. 카카오톡 원본은 그대로 유지됩니다. 이 작업은 되돌릴 수 없습니다. PC 동기화를 사용 중이면 다음 동기화에서 연결 기기의 자료도 삭제됩니다. 이미 복사한 클립보드 내용은 별도로 지워 주세요.", modifier = Modifier.verticalScroll(rememberScrollState())) },
        confirmButton = { TextButton(onClick = { store.deleteAll(); enabled = false; selection = emptySet(); detailId = null; deleteDialog = false }) { Text("전체 삭제") } },
        dismissButton = { TextButton(onClick = { deleteDialog = false }) { Text("취소") } })
    messages.find { it.id == detailId }?.let { message ->
        AlertDialog(onDismissRequest = { detailId = null }, title = { Text("${sourceName(message)} · ${message.sender}") },
            text = { LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Text("대화: ${message.conversation}\n받은 시간: ${formatTime(message.receivedAt)}") }
                item { Text(message.body) }
                item { OutlinedButton(onClick = { copy(listOf(message)) }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("메시지 복사") } }
                item { OutlinedButton(onClick = { openOriginal(message) }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("원래 대화로 이동") } }
                item { Text("원본 알림이 유효하면 해당 알림을 엽니다. 지원되지 않으면 카카오톡 앱을 열어 대화방을 선택합니다.") }
            } }, confirmButton = { TextButton(onClick = { detailId = null }) { Text("닫기") } })
    }
}

private fun sourceName(message: InboxMessage) = if(message.source == "IMPORT") "직접 가져온 내용" else "카카오톡"
