package kr.cacao.inbox

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
internal fun SyncPanel(store: MessageStore, incoming: String?, consumed: () -> Unit) {
    val context = LocalContext.current.applicationContext
    val scope = rememberCoroutineScope()
    val status by SyncEngine.status.collectAsStateWithLifecycle()
    var connected by remember { mutableStateOf(SyncPrefs.isEnabled(context)) }
    var dialog by remember { mutableStateOf(false) }
    var link by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var working by remember { mutableStateOf(false) }
    LaunchedEffect(incoming) { if(incoming != null) { link = incoming; dialog = true; consumed() } }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if(connected) status else "PC 동기화 꺼짐 · 메시지는 이 기기에만 저장됩니다")
        if(connected) {
            Button(onClick = { scope.launch { working = true; try { SyncEngine.run(context) } finally { working = false } } }, enabled = !working, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text(if(working) "연결 확인 중" else "지금 PC와 동기화") }
            OutlinedButton(onClick = { try { SyncSchedule.stop(context); connected = false } catch(_: Exception) { error = "중지 설정을 저장하지 못했습니다. 저장 공간을 확인해 주세요."; dialog = true } }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("PC 연결 해제") }
        } else OutlinedButton(onClick = { dialog = true }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("PC 연결") }
    }
    if(dialog) AlertDialog(onDismissRequest = { if(!working) { dialog = false; link = ""; error = null } },
        title = { Text("내 PC와 연결") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("PC 모아 메시지의 ‘갤럭시 연결’ QR을 카메라로 읽으면 연결 정보가 자동으로 들어옵니다. 같은 Wi-Fi에서 연결해 주세요.")
            OutlinedTextField(link, { link = it }, label = { Text("PC 연결 정보") }, modifier = Modifier.fillMaxWidth(), maxLines = 4)
            Text("동의하면 현재 저장된 메시지와 앞으로 수집하는 메시지, 확인·삭제 상태를 연결한 PC 및 기기와 동기화합니다. 메시지는 암호화해서 보내며 PC에도 암호화해 저장합니다.")
            Text("PC 앱이 실행 중이어야 합니다. 수집 후 동기화를 시도하며 Android 절전 정책에 따라 지연될 수 있습니다. 연결 해제는 이미 PC에 저장한 자료를 삭제하지 않습니다.")
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        } },
        confirmButton = { TextButton(enabled = !working, onClick = {
            scope.launch {
                working = true
                try {
                    val config = PairConfig.parse(link)
                    store.resetSyncCursor()
                    SyncPrefs.save(context, config)
                    SyncSchedule.configure(context)
                    connected = true; dialog = false; link = ""; error = null
                    SyncEngine.run(context)
                } catch(_: Exception) { error = "PC에서 만든 연결 정보를 확인해 주세요. Wi-Fi와 기기 저장 공간도 확인해 주세요." }
                finally { working = false }
            }
        }) { Text(if(working) "연결 중" else "동의하고 연결") } },
        dismissButton = { TextButton(enabled = !working, onClick = { dialog = false; link = ""; error = null }) { Text("취소") } })
}
