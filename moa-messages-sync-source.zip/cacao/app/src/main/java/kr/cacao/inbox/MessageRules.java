package kr.cacao.inbox;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;
import java.util.regex.Pattern;

/** Platform-independent rules; no message body is logged or sent to a server. */
public final class MessageRules {
    public static final String KAKAO_PACKAGE = "com.kakao.talk";
    private static final Pattern SENSITIVE = Pattern.compile(
        "인증|일회용|비밀번호|보안\\s*코드|verification|password|passcode|one[ -]?time|\\botp\\b", Pattern.CASE_INSENSITIVE);
    private MessageRules() {}
    public static boolean accepts(String packageName, boolean summary, String body) {
        return KAKAO_PACKAGE.equals(packageName) && !summary && body != null && !body.trim().isEmpty();
    }
    public static boolean sensitive(String body) { return body != null && SENSITIVE.matcher(body).find(); }
    public static String id(String conversationKey, String sender, String body, long messageTime) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            // Length-prefix fields to avoid delimiter collisions across conversations.
            for (String field : new String[]{conversationKey, sender, body, Long.toString(messageTime)}) {
                byte[] bytes = field.getBytes(StandardCharsets.UTF_8);
                digest.update(Integer.toString(bytes.length).getBytes(StandardCharsets.US_ASCII));
                digest.update((byte) ':');
                digest.update(bytes);
            }
            StringBuilder out = new StringBuilder();
            for (byte b : digest.digest()) out.append(String.format(Locale.ROOT, "%02x", b & 0xff));
            return out.toString();
        } catch (NoSuchAlgorithmException impossible) { throw new IllegalStateException(impossible); }
    }
}
