package kr.cacao.inbox

import android.app.KeyguardManager
import android.app.Notification
import android.app.PendingIntent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.concurrent.ConcurrentHashMap

/** Only notification text provided by Android is inspected. No Kakao database access. */
class KakaoNotificationListener : NotificationListenerService() {
    companion object {
        val connected = MutableStateFlow(false)
        private val openActions = ConcurrentHashMap<String, PendingIntent>()
        fun openOriginal(key: String): Boolean {
            val action = openActions[key] ?: return false
            return try { action.send(); true } catch (_: PendingIntent.CanceledException) {
                openActions.remove(key); false
            }
        }
    }
    override fun onListenerConnected() { connected.value = true }
    override fun onListenerDisconnected() { connected.value = false; openActions.clear() }
    override fun onDestroy() { connected.value = false; openActions.clear(); super.onDestroy() }
    override fun onNotificationRemoved(sbn: StatusBarNotification) { openActions.remove(sbn.key) }
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val store = (application as InboxApplication).store
        if (!store.enabled || !getSystemService(KeyguardManager::class.java).isDeviceSecure) return
        val messages = try { NotificationExtractor.extract(sbn) } catch (_: RuntimeException) {
            store.error.value = "알림 형식을 읽지 못했습니다. 다음 새 알림에서 다시 시도합니다."
            return
        }
        if (messages.isEmpty()) return
        sbn.notification.contentIntent?.let { openActions[sbn.key] = it }
        store.add(messages)
    }
}

internal object NotificationExtractor {
    fun extract(sbn: StatusBarNotification): List<InboxMessage> {
        val n = sbn.notification
        if (sbn.packageName != MessageRules.KAKAO_PACKAGE || n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return emptyList()
        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty().ifBlank { "보낸 사람 미표시" }
        val conversation = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString().orEmpty().ifBlank { title }
        val style = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(n)
        if (style != null && style.messages.isNotEmpty()) {
            // The visible current messages only; do not import historicMessages or attachments.
            return style.messages.mapNotNull { message ->
                val body = message.text?.toString().orEmpty()
                val sender = message.person?.name?.toString().orEmpty().ifBlank { title }
                val timestamp = message.timestamp.takeIf { it > 0 } ?: 0L
                make(sbn, conversation, sender, body, timestamp)
            }
        }
        val body = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            ?.takeIf { it.isNotBlank() } ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        // No stable per-message time exists in plain notifications. Use a content fingerprint;
        // identical repeats under the same notification key are intentionally deduplicated.
        return listOfNotNull(make(sbn, conversation, title, body, 0L))
    }
    private fun make(sbn: StatusBarNotification, conversation: String, sender: String, body: String, timestamp: Long): InboxMessage? {
        if (!MessageRules.accepts(sbn.packageName, false, body) || MessageRules.sensitive(body)) return null
        return InboxMessage(
            MessageRules.id(sbn.key + "|" + conversation, sender, body, timestamp), sbn.key,
            conversation, sender, body, if (timestamp > 0) timestamp else sbn.postTime,
        )
    }
}
