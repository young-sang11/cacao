package kr.cacao.inbox

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.channels.Channel
import java.util.concurrent.atomic.AtomicLong

data class InboxMessage(
    val id: String,
    val notificationKey: String,
    val conversation: String,
    val sender: String,
    val body: String,
    val receivedAt: Long,
    val checked: Boolean = false,
    val source: String = "KAKAO",
)

class InboxApplication : Application() {
    val store by lazy { MessageStore(this) }
}

private class InboxDatabase(context: Context) : SQLiteOpenHelper(context, "inbox.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE messages (
            id TEXT PRIMARY KEY NOT NULL, notification_key TEXT NOT NULL,
            conversation TEXT NOT NULL, sender TEXT NOT NULL, body TEXT NOT NULL,
            received_at INTEGER NOT NULL, checked INTEGER NOT NULL DEFAULT 0, source TEXT NOT NULL DEFAULT 'KAKAO')""")
        db.execSQL("CREATE INDEX message_time ON messages(received_at DESC)")
        createSyncTables(db)
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion == 1 && newVersion == 2) {
            db.execSQL("ALTER TABLE messages ADD COLUMN source TEXT NOT NULL DEFAULT 'KAKAO'")
            createSyncTables(db)
        } else error("지원하지 않는 데이터베이스 변경입니다. 저장 자료를 보호하기 위해 중단합니다.")
    }
    private fun createSyncTables(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS sync_deleted(id TEXT PRIMARY KEY NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS sync_meta(k TEXT PRIMARY KEY NOT NULL, v TEXT NOT NULL)")
    }
    override fun onConfigure(db: SQLiteDatabase) {
        db.rawQuery("PRAGMA secure_delete=ON", null).use { it.moveToFirst() }
    }
}

class MessageStore(private val context: Context) {
    private val database = InboxDatabase(context.applicationContext)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val operations = Channel<() -> Unit>(Channel.UNLIMITED)
    private val mutableMessages = MutableStateFlow<List<InboxMessage>>(emptyList())
    val messages = mutableMessages.asStateFlow()
    val error = MutableStateFlow<String?>(null)
    private val prefs = context.getSharedPreferences("collection", Context.MODE_PRIVATE)
    private val consentGeneration = AtomicLong(0)
    val enabled get() = prefs.getBoolean("consented", false)
    fun setEnabled(value: Boolean) {
        consentGeneration.incrementAndGet()
        prefs.edit().putBoolean("consented", value).commit()
    }
    init {
        scope.launch {
            for (action in operations) {
                try {
                    action()
                    mutableMessages.value = readAll()
                    error.value = null
                } catch (_: Exception) {
                    error.value = "저장 자료를 처리하지 못했습니다. 저장 공간을 확인한 뒤 앱을 다시 열어 주세요."
                }
            }
        }
        runOperation {}
    }
    private fun runOperation(action: () -> Unit) {
        if (operations.trySend(action).isFailure) error.value = "저장 작업을 시작하지 못했습니다. 앱을 다시 열어 주세요."
    }
    fun add(messages: List<InboxMessage>) {
        val generation = consentGeneration.get()
        runOperation {
            // Recheck consent inside the queue so pausing/deleting cannot race queued inserts.
            if (enabled && generation == consentGeneration.get()) {
                val db = database.writableDatabase
                db.beginTransaction()
                try {
                    messages.forEach { m ->
                        val deleted = db.rawQuery("SELECT 1 FROM sync_deleted WHERE id=?", arrayOf(m.id)).use { it.moveToFirst() }
                        if (deleted) return@forEach
                        val values = ContentValues().apply {
                            put("id", m.id); put("notification_key", m.notificationKey)
                            put("conversation", m.conversation); put("sender", m.sender)
                            put("body", m.body); put("received_at", m.receivedAt); put("checked", 0); put("source", m.source)
                        }
                        db.insertWithOnConflict("messages", null, values, SQLiteDatabase.CONFLICT_IGNORE)
                    }
                    db.setTransactionSuccessful()
                } finally { db.endTransaction() }
                SyncSchedule.soon(context)
            }
        }
    }
    fun markChecked(ids: Set<String>) = runOperation {
        val db = database.writableDatabase
        db.beginTransaction()
        try {
            ids.forEach { id -> db.update("messages", ContentValues().apply { put("checked", 1) }, "id=?", arrayOf(id)) }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        SyncSchedule.soon(context)
    }
    fun deleteAll() {
        setEnabled(false)
        runOperation {
            val db = database.writableDatabase
            db.beginTransaction()
            try {
                db.execSQL("INSERT OR IGNORE INTO sync_deleted SELECT id FROM messages")
                db.delete("messages", null, null)
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
            SyncSchedule.soon(context)
        }
    }

    private suspend fun <T> queued(block: () -> T): T {
        val result = CompletableDeferred<T>()
        runOperation {
            try { result.complete(block()) } catch (e: Exception) { result.completeExceptionally(e); throw e }
        }
        return result.await()
    }
    internal suspend fun syncSnapshot(): SyncSnapshot = queued {
        val db = database.readableDatabase
        val deleted = buildList { db.rawQuery("SELECT id FROM sync_deleted", null).use { c -> while(c.moveToNext()) add(c.getString(0)) } }
        val cursor = db.rawQuery("SELECT v FROM sync_meta WHERE k='cursor'", null).use { if(it.moveToFirst()) it.getString(0).toLong() else 0L }
        val instance = db.rawQuery("SELECT v FROM sync_meta WHERE k='instance'", null).use { if(it.moveToFirst()) it.getString(0) else null }
        SyncSnapshot(readAll(), deleted, cursor, instance)
    }
    internal suspend fun resetSyncCursor() = queued { database.writableDatabase.delete("sync_meta", null, null); Unit }
    internal suspend fun applySync(rows: List<SyncIncoming>, cursor: Long, instance: String) = queued {
        val db = database.writableDatabase
        db.beginTransaction()
        try {
            rows.forEach { row ->
                if (row.deleted) {
                    db.insertWithOnConflict("sync_deleted", null, ContentValues().apply { put("id", row.id) }, SQLiteDatabase.CONFLICT_IGNORE)
                    db.delete("messages", "id=?", arrayOf(row.id))
                } else if (row.message != null) {
                    val removed = db.rawQuery("SELECT 1 FROM sync_deleted WHERE id=?", arrayOf(row.id)).use { it.moveToFirst() }
                    if (!removed) {
                        val m = row.message
                        db.insertWithOnConflict("messages", null, ContentValues().apply {
                            put("id", m.id); put("notification_key", m.notificationKey); put("conversation", m.conversation)
                            put("sender", m.sender); put("body", m.body); put("received_at", m.receivedAt)
                            put("checked", if(row.checked) 1 else 0); put("source", m.source)
                        }, SQLiteDatabase.CONFLICT_IGNORE)
                        if(row.checked) db.update("messages", ContentValues().apply { put("checked", 1) }, "id=?", arrayOf(row.id))
                    }
                }
            }
            db.insertWithOnConflict("sync_meta", null, ContentValues().apply { put("k", "cursor"); put("v", cursor.toString()) }, SQLiteDatabase.CONFLICT_REPLACE)
            db.insertWithOnConflict("sync_meta", null, ContentValues().apply { put("k", "instance"); put("v", instance) }, SQLiteDatabase.CONFLICT_REPLACE)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
    private fun readAll(): List<InboxMessage> = buildList {
        database.readableDatabase.query("messages", null, null, null, null, null, "received_at DESC, id ASC").use { c ->
            fun str(name: String) = c.getString(c.getColumnIndexOrThrow(name))
            while (c.moveToNext()) add(InboxMessage(
                str("id"), str("notification_key"), str("conversation"), str("sender"), str("body"),
                c.getLong(c.getColumnIndexOrThrow("received_at")), c.getInt(c.getColumnIndexOrThrow("checked")) == 1, str("source"),
            ))
        }
    }
}
