package kr.cacao.inbox

import android.view.WindowManager
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], application = InboxApplication::class)
class AppLaunchTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()
    @Test fun appStartsLockedAndDisplaysKoreanUnlockButton() {
        compose.onNodeWithText("모아 메시지").assertIsDisplayed()
        compose.onNodeWithText("잠금 해제").assertIsDisplayed()
        compose.onNodeWithText("통합 메시지함").assertDoesNotExist()
        assertTrue(compose.activity.window.attributes.flags and WindowManager.LayoutParams.FLAG_SECURE != 0)
    }
}
