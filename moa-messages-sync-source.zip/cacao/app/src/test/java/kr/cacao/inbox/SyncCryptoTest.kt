package kr.cacao.inbox

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import android.app.Application
import android.content.Context
import org.robolectric.RuntimeEnvironment
import kotlinx.coroutines.runBlocking

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], application = Application::class)
class SyncCryptoTest {
    private fun vector() = javaClass.classLoader!!.getResourceAsStream("sync-vector.json")!!.use { JSONObject(String(it.readBytes(), Charsets.UTF_8)) }
    @Test fun decryptsNodeGeneratedMessageAndDerivesSameToken() {
        val v = vector()
        assertEquals(v.getString("token"), SyncCrypto.token(v.getString("secret")))
        val result = SyncCrypto.decrypt(v.getJSONObject("item"), v.getString("secret"))
        assertEquals("영희", result.sender)
        assertEquals("업무방", result.conversation)
        assertEquals("내일 오후 3시에 만나요", result.body)
        assertEquals(v.getJSONObject("message").getLong("receivedAt"), result.receivedAt)
        val encrypted = SyncCrypto.encrypt(result, v.getString("secret"))
        assertEquals(result, SyncCrypto.decrypt(encrypted, v.getString("secret")))
        assertFalse(encrypted.toString().contains(result.body))
    }
    @Test fun rejectsModifiedIdentityAndWrongKeys() {
        val v = vector(); val secret = v.getString("secret")
        assertThrows(Exception::class.java) { SyncCrypto.decrypt(v.getJSONObject("item"), "c".repeat(64)) }
        val changed = JSONObject(v.getJSONObject("item").toString()).put("id", "d".repeat(64))
        assertThrows(Exception::class.java) { SyncCrypto.decrypt(changed, secret) }
    }
    @Test fun appliesRemoteReadAndDeletionWithoutResurrectingFromStalePhone() = runBlocking {
        val context = RuntimeEnvironment.getApplication()
        context.deleteDatabase("inbox.db")
        context.getSharedPreferences("collection", Context.MODE_PRIVATE).edit().clear().commit()
        val store = MessageStore(context)
        val v = vector(); val m = SyncCrypto.decrypt(v.getJSONObject("item"), v.getString("secret"))
        store.applySync(listOf(SyncIncoming(m.id, false, true, m)), 1L, "test-relay")
        assertTrue(store.syncSnapshot().messages.single().checked)
        store.applySync(listOf(SyncIncoming(m.id, true, true, null)), 2L, "test-relay")
        store.setEnabled(true); store.add(listOf(m))
        val snapshot = store.syncSnapshot()
        assertTrue(snapshot.messages.isEmpty()); assertEquals(listOf(m.id), snapshot.deleted)
        assertEquals(2L, snapshot.cursor); assertEquals("test-relay", snapshot.instance)
        store.applySync(listOf(SyncIncoming(m.id, false, false, m)), 3L, "test-relay")
        assertTrue(store.syncSnapshot().messages.isEmpty())
    }
    @Test fun upgradesVersionOneDatabaseWithoutLosingOriginalMessage() = runBlocking {
        val context = RuntimeEnvironment.getApplication()
        context.deleteDatabase("inbox.db")
        val v=vector(); val m=SyncCrypto.decrypt(v.getJSONObject("item"),v.getString("secret"))
        context.openOrCreateDatabase("inbox.db",0,null).use { db ->
            db.execSQL("CREATE TABLE messages(id TEXT PRIMARY KEY NOT NULL,notification_key TEXT NOT NULL,conversation TEXT NOT NULL,sender TEXT NOT NULL,body TEXT NOT NULL,received_at INTEGER NOT NULL,checked INTEGER NOT NULL DEFAULT 0)")
            db.execSQL("INSERT INTO messages VALUES(?,?,?,?,?,?,?)", arrayOf(m.id,"old-key",m.conversation,m.sender,m.body,m.receivedAt,1))
            db.version=1
        }
        val snapshot=MessageStore(context).syncSnapshot()
        assertEquals(m.body,snapshot.messages.single().body)
        assertEquals("old-key",snapshot.messages.single().notificationKey)
        assertEquals("KAKAO",snapshot.messages.single().source)
        assertTrue(snapshot.messages.single().checked)
    }
    @Test fun connectionInformationRequiresTlsAndValidPinnedCertificate() {
        val bytes = android.util.Base64.encodeToString(JSONObject().put("version",1).put("urls",org.json.JSONArray(listOf("http://192.168.0.2:44589"))).put("secret","a".repeat(64)).put("fingerprint","b".repeat(64)).toString().toByteArray(), android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP)
        assertThrows(Exception::class.java) { PairConfig.parse("moainbox://pair?data=$bytes") }
        assertThrows(Exception::class.java) { PairConfig.parse("https://evil.example/") }
    }
}
