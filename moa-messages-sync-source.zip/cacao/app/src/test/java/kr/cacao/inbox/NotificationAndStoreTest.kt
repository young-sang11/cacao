package kr.cacao.inbox

import android.app.Application
import android.app.Notification
import android.app.Person
import android.os.Process
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], application = Application::class)
class NotificationAndStoreTest {
    private val context get() = RuntimeEnvironment.getApplication()
    @Before fun clean() {
        context.deleteDatabase("inbox.db")
        context.getSharedPreferences("collection", 0).edit().clear().commit()
    }
    private fun sbn(notification: Notification, pkg: String = "com.kakao.talk", id: Int = 1) =
        StatusBarNotification(pkg, pkg, id, "room", 1000, 0, 0, notification, Process.myUserHandle(), 5000L)
    private fun plain(text: String) = Notification.Builder(context, "messages")
        .setContentTitle("영희").setContentText(text).setSmallIcon(android.R.drawable.ic_dialog_email).build()

    @Test fun ignoresOtherAppsAndSummaryAndSensitiveContent() {
        assertTrue(NotificationExtractor.extract(sbn(plain("안녕"), "other.app")).isEmpty())
        val summary = Notification.Builder(context, "messages").setContentTitle("카카오톡")
            .setContentText("새 메시지 3개").setGroup("room").setGroupSummary(true).build()
        assertTrue(NotificationExtractor.extract(sbn(summary)).isEmpty())
        assertTrue(NotificationExtractor.extract(sbn(plain("인증번호 123456"))).isEmpty())
    }
    @Test fun plainTextHasStableIdAndPreservesOriginal() {
        val first = NotificationExtractor.extract(sbn(plain("안녕\n내일 만나요"))).single()
        val second = NotificationExtractor.extract(sbn(plain("안녕\n내일 만나요"))).single()
        assertEquals(first.id, second.id)
        assertEquals("영희", first.sender)
        assertEquals("안녕\n내일 만나요", first.body)
        assertEquals(5000L, first.receivedAt)
        assertFalse(first.checked)
        assertNotEquals(first.id, NotificationExtractor.extract(sbn(plain(first.body), id = 2)).single().id)
    }
    @Test fun messagingStyleSeparatesPeopleAndRepeatedMessagesByTimestamp() {
        val user = Person.Builder().setName("나").build()
        val sender = Person.Builder().setName("영희").build()
        val style = Notification.MessagingStyle(user).setConversationTitle("업무방").setGroupConversation(true)
            .addMessage("확인", 1000L, sender).addMessage("확인", 2000L, sender)
        val notification = Notification.Builder(context, "messages").setStyle(style).build()
        val items = NotificationExtractor.extract(sbn(notification))
        assertEquals(2, items.size)
        assertEquals("영희", items.first().sender)
        assertEquals("업무방", items.first().conversation)
        assertNotEquals(items.first().id, items.last().id)
        assertEquals(1000L, items.first().receivedAt)
    }
    @Test fun databaseDeduplicatesAndKeepsReadStatusAndPersistsAcrossInstances() = runBlocking {
        val store = MessageStore(context)
        store.setEnabled(true)
        val message = NotificationExtractor.extract(sbn(plain("안녕하세요"))).single()
        store.add(listOf(message, message))
        withTimeout(5000) { store.messages.first { it.size == 1 } }
        store.markChecked(setOf(message.id))
        withTimeout(5000) { store.messages.first { it.singleOrNull()?.checked == true } }
        store.add(listOf(message))
        val restored = MessageStore(context)
        val rows = withTimeout(5000) { restored.messages.first { it.size == 1 } }
        assertTrue(rows.single().checked)
        assertEquals(message.body, rows.single().body)
    }
    @Test fun disabledCollectionAndDeleteRejectQueuedMessages() = runBlocking {
        val store = MessageStore(context)
        val message = NotificationExtractor.extract(sbn(plain("일정 확인"))).single()
        store.setEnabled(true)
        store.add(listOf(message))
        withTimeout(5000) { store.messages.first { it.size == 1 } }
        store.deleteAll()
        store.add(listOf(message))
        withTimeout(5000) { store.messages.first { it.isEmpty() } }
        assertFalse(store.enabled)
        val reopened = MessageStore(context)
        // Wait for initial database read rather than accepting the initial empty StateFlow.
        reopened.markChecked(emptySet())
        assertEquals(0, context.openOrCreateDatabase("inbox.db", 0, null).use { db ->
            db.rawQuery("SELECT COUNT(*) FROM messages", null).use { c -> c.moveToFirst(); c.getInt(0) }
        })
    }
}
