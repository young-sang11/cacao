#!/usr/bin/env bash
# Source in cloud builds. No credentials are stored here.
export JAVA_HOME=/workspace/.tools/jdk-17.0.13+11
export ANDROID_HOME=/workspace/.tools/android-sdk
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export ANDROID_USER_HOME=/workspace/.tools/android-user
export GRADLE_USER_HOME=/workspace/.tools/gradle-home
export PATH="$JAVA_HOME/bin:/workspace/.tools/gradle-8.9/bin:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"
export JAVA_TOOL_OPTIONS="${JAVA_TOOL_OPTIONS:-} -Djavax.net.ssl.trustStore=/workspace/.tools/cacerts -XX:ActiveProcessorCount=4"
# Java does not automatically honor HTTP_PROXY. Use the inherited session route.
if [[ -n "${HTTPS_PROXY:-}" ]]; then
    task_proxy_options=$(python3 - <<'PY'
import os, urllib.parse
u=urllib.parse.urlparse(os.environ['HTTPS_PROXY'])
if not u.hostname or u.username or u.password:
    raise SystemExit('Unsupported proxy format; do not print credentials')
print(f'-Dhttps.proxyHost={u.hostname} -Dhttps.proxyPort={u.port or 80} -Dhttp.proxyHost={u.hostname} -Dhttp.proxyPort={u.port or 80}')
PY
)
    export GRADLE_OPTS="${GRADLE_OPTS:-} $task_proxy_options"
    export JAVA_TOOL_OPTIONS="$JAVA_TOOL_OPTIONS $task_proxy_options"
fi
