#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
task_classes=$(mktemp -d)
trap 'rm -rf "$task_classes"' EXIT
javac --release 17 -encoding UTF-8 -d "$task_classes" app/src/main/java/kr/cacao/inbox/MessageRules.java tests/MessageRulesCheck.java
java -cp "$task_classes" kr.cacao.inbox.MessageRulesCheck
