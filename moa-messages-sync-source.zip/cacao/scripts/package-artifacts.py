#!/usr/bin/env python3
"""Package the APK and source only; never include local DBs, credentials or caches."""
from pathlib import Path
import hashlib
import shutil
import zipfile

root = Path(__file__).resolve().parent.parent
out = root / 'artifacts'
out.mkdir(exist_ok=True)
apk = out / 'moa-messages-phase1-debug.apk'
shutil.copy2(root / 'app/build/outputs/apk/debug/app-debug.apk', apk)
source = out / 'cacao-phase1-source.zip'
files = [root / name for name in (
    '.gitignore', 'README.md', 'settings.gradle.kts', 'build.gradle.kts',
    'gradle.properties', 'gradlew', 'gradlew.bat',
)]
for name in ('app/src', 'docs', 'gradle', 'scripts', 'tests'):
    files.extend(p for p in (root / name).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
files.append(root / 'app/build.gradle.kts')
with zipfile.ZipFile(source, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(set(files)):
        archive.write(path, Path('cacao') / path.relative_to(root))
checksums = ''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in (apk, source))
(out / 'SHA256SUMS.txt').write_text(checksums)
for path in (apk, source):
    print(f'{path.name}: {path.stat().st_size:,} bytes')
