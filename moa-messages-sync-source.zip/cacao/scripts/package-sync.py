#!/usr/bin/env python3
from pathlib import Path
import zipfile,shutil,hashlib
root=Path(__file__).resolve().parent.parent
out=root/'artifacts';out.mkdir(exist_ok=True)
apk=out/'moa-messages-android-sync.apk'
shutil.copy2(root/'app/build/outputs/apk/debug/app-debug.apk',apk)
source=out/'moa-messages-sync-source.zip'
files=[root/name for name in ['.gitignore','README.md','settings.gradle.kts','build.gradle.kts','gradle.properties','gradlew','gradlew.bat','app/build.gradle.kts']]
for directory in ['app/src','desktop','web','sync','scripts','docs','tests','gradle']:
    files.extend(p for p in (root/directory).rglob('*') if p.is_file() and not {'build','node_modules','__pycache__'}.intersection(p.relative_to(root).parts))
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(set(files)):z.write(p,Path('cacao')/p.relative_to(root))
artifacts=[apk,out/'moa-messages-windows-setup.exe',source]
(out/'SYNC-SHA256SUMS.txt').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in artifacts))
for p in artifacts:print(p.name,f'{p.stat().st_size:,} bytes')
