#!/usr/bin/env bash
# Reproducible Linux cloud build tools. Downloads retain TLS and SHA-256 checks.
set -euo pipefail
cd "$(dirname "$0")/.."
task_root=/workspace/.tools
mkdir -p "$task_root/downloads"
fetch() {
    local name=$1 url=$2 expected=$3
    local target="$task_root/downloads/$name"
    if [[ ! -f "$target" ]] || [[ $(sha256sum "$target" | cut -d' ' -f1) != "$expected" ]]; then
        curl --fail --location --retry 2 --output "$target" "$url"
    fi
    echo "$expected  $target" | sha256sum --check --status
}
fetch sdk.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip 2d2d50857e4eb553af5a6dc3ad507a17adf43d115264b1afc116f95c92e5e258
fetch gradle.zip https://services.gradle.org/distributions/gradle-8.9-bin.zip d725d707bfabd4dfdc958c624003b3c80accc03f7037b5122c4b1d0ef15cecab
fetch jdk.tar.gz https://github.com/adoptium/temurin17-binaries/releases/download/jdk-17.0.13%2B11/OpenJDK17U-jdk_x64_linux_hotspot_17.0.13_11.tar.gz 8682892fc02965930b9022c066fa164dd6f458ef4a5dc262016aa28333b30f49
python3 - <<'PY'
import pathlib,tarfile,zipfile
p=pathlib.Path('/workspace/.tools')
if not (p/'jdk-17.0.13+11/bin/javac').exists():
    with tarfile.open(p/'downloads/jdk.tar.gz') as t:t.extractall(p,filter='data')
if not (p/'gradle-8.9/bin/gradle').exists():
    with zipfile.ZipFile(p/'downloads/gradle.zip') as z:z.extractall(p)
    (p/'gradle-8.9/bin/gradle').chmod(0o755)
if not (p/'android-sdk/cmdline-tools/latest/bin/sdkmanager').exists():
    sdk=p/'android-sdk/cmdline-tools'
    sdk.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(p/'downloads/sdk.zip') as z:z.extractall(sdk)
    (sdk/'cmdline-tools').rename(sdk/'latest')
    for file in (sdk/'latest/bin').iterdir():file.chmod(0o755)
PY
# Refresh trust from the machine, then add only the platform's configured CA.
cp /etc/ssl/certs/java/cacerts "$task_root/cacerts"
source scripts/cloud-env.sh
if [[ -n "${CODEX_PROXY_CERT:-}" && -f "$CODEX_PROXY_CERT" ]]; then
    keytool -importcert -noprompt -alias codex-session-proxy -file "$CODEX_PROXY_CERT" -keystore "$task_root/cacerts" -storepass changeit
fi
task_sdk_proxy=()
if [[ -n "${HTTPS_PROXY:-}" ]]; then
    mapfile -t task_proxy_parts < <(python3 - <<'PY'
import os,urllib.parse
u=urllib.parse.urlparse(os.environ['HTTPS_PROXY'])
print(u.hostname); print(u.port or 80)
PY
)
    task_sdk_proxy=(--proxy=http "--proxy_host=${task_proxy_parts[0]}" "--proxy_port=${task_proxy_parts[1]}")
fi
# yes can exit with SIGPIPE after sdkmanager succeeds; preserve sdkmanager's status.
set +o pipefail
yes | sdkmanager --sdk_root="$ANDROID_HOME" "${task_sdk_proxy[@]}" --licenses > "$task_root/sdk-licenses.log" 2>&1
task_license_status=${PIPESTATUS[1]}
set -o pipefail
if [[ $task_license_status != 0 ]]; then exit "$task_license_status"; fi
sdkmanager --sdk_root="$ANDROID_HOME" "${task_sdk_proxy[@]}" 'platforms;android-35' 'build-tools;35.0.0' 'platform-tools'
scripts/test-core.sh
gradle --no-daemon assembleDebug testDebugUnitTest lintDebug --console=plain
