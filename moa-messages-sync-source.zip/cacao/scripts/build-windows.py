#!/usr/bin/env python3
"""Cross-build the Windows installer with retained, verified official tools."""
from pathlib import Path
import os, shutil, subprocess, hashlib
root=Path(__file__).resolve().parent.parent
nsis=Path('/workspace/.tools/nsis/usr')
node=Path('/workspace/.tools/node-v24.11.1-win-x64')
expected='5355ae6d7c49eddcfde7d34ac3486820600a831bf81dc3bdca5c8db6a9bb0e76'
assert hashlib.sha256(Path('/workspace/.tools/downloads/node-win.zip').read_bytes()).hexdigest()==expected
payload=root/'desktop/build/payload'
payload.mkdir(parents=True,exist_ok=True)
(payload/'runtime').mkdir(exist_ok=True)
for name in ['node.exe','LICENSE']:
    shutil.copy2(node/name,payload/'runtime'/name)
for directory in ['desktop','web']:
    target=payload/directory
    if target.exists():shutil.rmtree(target)
    shutil.copytree(root/directory,target,ignore=shutil.ignore_patterns('build','tests','installer','*.sqlite','*.dpapi','*.pfx','*.cer'))
env={**os.environ,'NSISDIR':str(nsis/'share/nsis')}
# Debian separates NSIS runtime stubs/plugins into lib, with share path symlinks.
compiler=nsis/'bin/makensis'
def run(source,**defines):
    subprocess.run([str(compiler),'-V2',*[f'-D{k}={v}' for k,v in defines.items()],str(root/'desktop/installer'/source)],env=env,check=True)
run('launcher.nsi',OUT=payload/'MoaMessages.exe')
out=root/'artifacts/moa-messages-windows-setup.exe'
run('setup.nsi',OUT=out,PAYLOAD=payload)
assert out.read_bytes()[:2]==b'MZ'
print(f'Windows installer built: {out.name} ({out.stat().st_size:,} bytes)')
