#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
task_root=/workspace/.tools
mkdir -p "$task_root/downloads" "$task_root/nsis"
fetch() {
    local name=$1 url=$2 expected=$3 target="$task_root/downloads/$1"
    if [[ ! -f "$target" ]] || [[ $(sha256sum "$target" | cut -d' ' -f1) != "$expected" ]]; then
        curl --fail --location --retry 2 --output "$target" "$url"
    fi
    echo "$expected  $target" | sha256sum --check --status
}
# Hashes were checked against the official Node release manifest and signed Debian metadata.
fetch node-win.zip https://nodejs.org/dist/v24.11.1/node-v24.11.1-win-x64.zip 5355ae6d7c49eddcfde7d34ac3486820600a831bf81dc3bdca5c8db6a9bb0e76
fetch nsis_3.11-1_amd64.deb https://deb.debian.org/debian/pool/main/n/nsis/nsis_3.11-1_amd64.deb e6eb6ffb70f0df09e95dedb2d2cf55ad3c2679f7c2ae357d0c00cc4c83178690
fetch nsis-common_3.11-1_all.deb https://deb.debian.org/debian/pool/main/n/nsis/nsis-common_3.11-1_all.deb 103a3284c1a5356efa0aba90fdfc391c3cde8e7df8726377cef0f98471584047
for package in "$task_root/downloads/"nsis*.deb; do dpkg-deb -x "$package" "$task_root/nsis"; done
python3 - <<'PY'
from pathlib import Path
import zipfile
p=Path('/workspace/.tools')
if not (p/'node-v24.11.1-win-x64/node.exe').exists():
    with zipfile.ZipFile(p/'downloads/node-win.zip') as z:z.extractall(p)
PY
(cd desktop && npm ci --ignore-scripts --no-audit --no-fund && npm test)
python3 scripts/build-windows.py
