#!/usr/bin/env python3
from pathlib import Path
import hashlib,zipfile
root=Path(__file__).resolve().parent.parent
source=root/'standalone'
html=(source/'index.html').read_text().replace('/* INLINE_STYLE */',(source/'style.css').read_text()).replace('/* INLINE_SCRIPT */',(source/'app.js').read_text())
assert '/* INLINE_' not in html
out=root/'artifacts';out.mkdir(exist_ok=True)
file=out/'moa-messages.html';file.write_text(html,encoding='utf-8')
with zipfile.ZipFile(out/'moa-messages-html.zip','w',zipfile.ZIP_DEFLATED) as z:z.write(file,'모아메시지.html')
(out/'HTML-SHA256SUMS.txt').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in [file,out/'moa-messages-html.zip']))
print('Built single HTML:',file.stat().st_size,'bytes; no external resources or server required.')
