package kr.cacao.inbox;

/** Dependency-free executable tests for capture filtering and stable message identity. */
public final class MessageRulesCheck {
    private static int checks;
    private static void check(boolean actual, String name) {
        checks++;
        if (!actual) throw new AssertionError(name);
    }
    public static void main(String[] args) {
        check(MessageRules.accepts("com.kakao.talk", false, "안녕하세요"), "accept Kakao text");
        check(!MessageRules.accepts("other.app", false, "hello"), "reject unrelated apps");
        check(!MessageRules.accepts("com.kakao.talk", true, "새 메시지 3개"), "reject summaries");
        check(!MessageRules.accepts("com.kakao.talk", false, "  "), "reject empty body");
        check(!MessageRules.accepts("com.kakao.talk", false, null), "reject null body");
        check(MessageRules.sensitive("인증번호는 123456입니다"), "protect Korean codes");
        check(MessageRules.sensitive("Your verification code is 123456"), "protect English codes");
        check(MessageRules.sensitive("OTP 1234"), "protect OTP");
        check(MessageRules.sensitive("비밀번호를 확인하세요"), "protect password");
        check(!MessageRules.sensitive("내일 오후 3시에 만나요"), "retain normal message");
        String original = MessageRules.id("room1", "영희", "안녕", 100);
        check(original.equals(MessageRules.id("room1", "영희", "안녕", 100)), "stable duplicate identity");
        check(!original.equals(MessageRules.id("room2", "영희", "안녕", 100)), "isolate rooms");
        check(!original.equals(MessageRules.id("room1", "철수", "안녕", 100)), "isolate senders");
        check(!original.equals(MessageRules.id("room1", "영희", "안녕", 101)), "retain repeated text at new time");
        check(!MessageRules.id("a|b", "c", "d", 0).equals(MessageRules.id("a", "b|c", "d", 0)), "prevent delimiter collision");
        check(original.matches("[0-9a-f]{64}"), "hashed identifier format");
        System.out.println("PASS: " + checks + " capture and identity checks");
    }
}
