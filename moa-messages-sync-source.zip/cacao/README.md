# HTML 파일 버전

사용자 요청에 따라 **설치 없이 여는 단일 HTML 버전**을 추가했습니다.
`artifacts/moa-messages.html`을 내려받아 Edge/Chrome에서 여세요. 앱 사용에 Node·서버·설치 EXE가 필요 없습니다.
[HTML 버전 사용 안내](standalone/README.md)를 확인하세요. 자동 수신·자동 동기화는 이 파일에서 지원하지 않습니다.

아래 설치형 프로그램은 이전 별도 구현이며 HTML 파일 사용에는 필요하지 않습니다.

# 모아 메시지 0.2 — 갤럭시·Windows 설치형 동기화

갤럭시 카카오톡 알림을 기기 내부에 저장하고, **사용자가 동의하면 같은 네트워크의 Windows PC와 암호화 동기화**합니다.
PC는 별도 Node/Python/서버 설정 없이 설치 EXE로 실행합니다. Microsoft Edge가 있으면 독립 앱 창으로, 없으면 기본 브라우저로 표시합니다.

## 설치 후 사용 — 세 단계

1. **PC:** `moa-messages-windows-setup.exe`를 실행하고 **설치**를 누릅니다. 바탕화면의 **모아 메시지**를 실행합니다.
2. **갤럭시:** `moa-messages-android-sync.apk`를 설치하고 기기 잠금을 해제한 뒤, 앱 안내에 따라 카카오톡 **알림 접근을 허용**합니다.
3. 두 기기를 같은 공유기 네트워크에 연결합니다(PC는 유선 연결도 가능). PC 앱의 **갤럭시 연결**을 누르고 갤럭시 카메라로 QR을 읽습니다. 갤럭시 앱에서 **동의하고 연결**을 누릅니다.

Windows 10/11 64비트와 Android 11 이상이 필요합니다. 운영체제의 설치 확인과 Android 알림 접근 허용은 생략할 수 없습니다.
APK는 USB로 갤럭시 Download 폴더에 복사한 뒤 ‘내 파일 → 다운로드’에서 열 수 있습니다.
QR 카메라가 앱 연결을 지원하지 않으면 PC의 연결 정보를 갤럭시 앱 ‘PC 연결’에 붙여넣는 대체 방식을 제공합니다.

**개발용 설치 파일이며, 배포자 코드 서명이 없어 Windows SmartScreen 또는 Android의 추가 설치 확인이 나타날 수 있습니다.**
현재 환경에서 Windows 실제 설치와 갤럭시 실수신·QR 카메라 연결은 미검증입니다. 자동 테스트 통과를 실기기 검증으로 보지 마세요.
설치 파일은 GitHub의 `downloads/installers` 브랜치에 게시했습니다. EXE·APK·소스 ZIP을 실제 HTTPS 다운로드 주소에서 다시 받아 SHA-256이 일치하는지 확인했습니다.

## 구현한 기능

- 카카오톡 새 알림의 발신자·시간·원문 수집. 요약 알림/민감 문구 제외. 기존 대화나 첨부파일 자동 추출 없음.
- 갤럭시 내부 SQLite 저장, 미확인 구분, 검색·정렬, 다중 선택·복사, 앱 잠금·자료 삭제.
- PC 한국어 큰 글씨 수신함, 검색·선택·복사·확인·삭제, 직접 복사한 PC 대화 가져오기.
- AES-256-GCM 암호화 메시지 동기화, TLS와 PC 인증서 지문 검증, 확인·삭제 상태 병합, 재시도 중복 방지.
- PC의 QR로 한 번 연결, 명시적 동의 후 수집/확인/삭제 시 백그라운드 동기화 시도 및 주기적 재시도.
- PC 연결키는 Windows DPAPI, 갤럭시 연결키는 Android Keystore로 보호.
- PC 잠금 시 브라우저의 메시지/키/연결 QR 표시 제거. 5분 미사용 시 자동 잠금. 앱 아이콘을 다시 실행해 열기.

## 사용 조건과 제한

- PC가 켜져 있고 앱이 실행 중이어야 합니다. 창만 닫으면 앱은 계속 실행되며 ‘PC 앱 완전히 종료’로 종료합니다.
- **기본 동기화는 같은 로컬 네트워크용입니다. 서로 다른 인터넷 회선에서의 자동 접속이나 공용 중계는 구현하지 않았습니다.** 원격 사용에는 별도 VPN/관리되는 서버 구성이 필요합니다.
- 회사·게스트 Wi-Fi의 기기 간 통신 차단 정책을 우회하지 않습니다. PC 앱 설치는 해당 프로그램/포트 44589만 로컬 서브넷에 허용합니다.
- Wi-Fi/PC IP가 바뀌면 PC 앱을 종료 후 다시 실행하고 연결 QR을 다시 확인해야 할 수 있습니다. 자동 네트워크 검색은 아직 없습니다.
- Android 절전/백그라운드 정책에 따라 자동 동기화는 지연될 수 있습니다. ‘지금 PC와 동기화’로 수동 재시도할 수 있습니다.
- 연결 해제는 이미 다른 기기에 저장한 내용을 지우지 않습니다. 연결된 기기는 전체 메시지를 볼 수 있으므로 QR을 내 기기에서만 사용하세요.
- 메시지 삭제는 다음 동기화에서 연결 기기에 반영됩니다. 카카오톡 원본/클립보드/외부 복사본은 지우지 않습니다. 삭제된 ID 표식은 재삽입 방지용으로 남습니다.
- PC DB에는 암호문을 저장합니다. 갤럭시 원문 DB는 OS의 앱 저장소/기기 암호화에 의존하며 별도 DB 암호화는 미적용입니다.
- Windows 앱 제거 시 개인 메시지와 연결 설정은 `%LOCALAPPDATA%\MoaMessages`에 남습니다. 자료를 먼저 앱에서 삭제할 수 있습니다. 계정/키 복구와 기기별 개별 권한 취소는 미구현입니다.
- 동기화 서버는 삭제 표식 포함 10,000개 ID까지 보관합니다. 한도 초과 시 실패를 알리고 자료를 자동 폐기하지 않습니다.
- 일반 알림은 메시지별 시각이 없어 같은 알림 키의 동일 문구가 중복 제거될 수 있습니다. 알림에 가려진 내용은 복원하지 않습니다.
- ‘확인 완료’는 이 앱의 상태이며 카카오톡의 읽음 상태와는 다릅니다. 민감 문구 필터는 모든 민감 정보를 판별하지 못합니다.
- SMS·첨부파일·ChatGPT 공유·AI 답장 추천·캘린더는 후속 단계입니다. 답장 자동 전송 기능은 없습니다.
- PC 카카오톡 자동 수집/화면 조작은 하지 않습니다. PC 앱의 메시지 도착 토스트/트레이 기능은 아직 없습니다.

## 개발 및 빌드

Android Studio 또는 JDK 17 / Android SDK 35:

```bash
./gradlew --no-daemon assembleDebug testDebugUnitTest lintDebug
```

Linux 클라우드의 재현 절차:

```bash
bash scripts/setup-cloud.sh
bash scripts/setup-desktop.sh
python3 scripts/package-sync.py
```

`setup-desktop.sh`는 Node 24+, Python 3, dpkg-deb, curl, OpenSSL을 요구합니다. Windows 런타임은 공식 배포 체크섬,
NSIS는 서명 검증된 Debian 패키지에서 확보한 고정 SHA-256으로 검증합니다. TLS/체크섬 검증을 비활성화하지 않습니다.
QR 라이브러리는 `desktop/package-lock.json`으로 고정하고 `npm ci --ignore-scripts`로 설치합니다.

서버/API 검사: `cd desktop && npm test`.
브라우저 기능 검사: Playwright와 Chromium이 있는 개발 환경에서 `MOA_BROWSER_EXECUTABLE=/usr/bin/chromium node desktop/tests/browser.mjs`.
수집 규칙: JDK 활성화 후 `scripts/test-core.sh`.

결과물은 `artifacts`의 Windows EXE, Android APK, 전체 소스 ZIP 및 `SYNC-SHA256SUMS.txt`입니다.
설치 도구·키·메시지 DB·node_modules는 소스 ZIP에 포함하지 않습니다.

[동기화 규약](sync/protocol.md) · [실기기 확인](docs/sync-device-test.md) · [자동 검증 결과](docs/sync-validation.md)
