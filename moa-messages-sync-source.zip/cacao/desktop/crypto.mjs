import {createHash, randomBytes, createCipheriv, createDecipheriv} from 'node:crypto';
export const deriveToken = secret => createHash('sha256').update('moa:auth:v1:' + secret).digest('hex');
export const deriveKey = secret => createHash('sha256').update('moa:encryption:v1:' + secret).digest();
export function encryptMessage(message, secret) {
  const iv = randomBytes(12), cipher = createCipheriv('aes-256-gcm', deriveKey(secret), iv);
  cipher.setAAD(Buffer.from('moa:v1:' + message.id));
  const ciphertext = Buffer.concat([cipher.update(JSON.stringify(message)), cipher.final(), cipher.getAuthTag()]);
  return {id:message.id, iv:iv.toString('base64'), ciphertext:ciphertext.toString('base64'), checked:false, deleted:false};
}
export function decryptMessage(item, secret) {
  const data=Buffer.from(item.ciphertext,'base64'), decipher=createDecipheriv('aes-256-gcm',deriveKey(secret),Buffer.from(item.iv,'base64'));
  decipher.setAAD(Buffer.from('moa:v1:'+item.id)); decipher.setAuthTag(data.subarray(-16));
  const message=JSON.parse(Buffer.concat([decipher.update(data.subarray(0,-16)),decipher.final()]).toString());
  if(message.id!==item.id) throw new Error('Message identity mismatch');
  return message;
}
