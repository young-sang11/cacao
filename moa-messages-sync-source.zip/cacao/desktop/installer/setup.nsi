Unicode true
!include "MUI2.nsh"
!include "x64.nsh"
Name "모아 메시지"
OutFile "${OUT}"
InstallDir "$PROGRAMFILES64\MoaMessages"
RequestExecutionLevel admin
SetCompressor /SOLID lzma
!define MUI_ABORTWARNING
!define MUI_WELCOMEPAGE_TITLE "모아 메시지 설치"
!define MUI_WELCOMEPAGE_TEXT "PC와 갤럭시의 메시지를 한곳에서 확인합니다.$\r$\n$\r$\n설치를 누르면 필요한 실행 도구와 연결 설정을 자동으로 준비합니다. 설치 후 바탕화면의 모아 메시지를 실행해 주세요."
!define MUI_FINISHPAGE_TITLE "설치가 완료되었습니다"
!define MUI_FINISHPAGE_TEXT "바탕화면의 모아 메시지 아이콘을 실행하세요.$\r$\n$\r$\n앱에서 갤럭시 연결을 누르고 휴대전화로 QR을 읽으면 연결할 수 있습니다."
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Korean"
Function .onInit
  ${IfNot} ${RunningX64}
    MessageBox MB_ICONSTOP "Windows 10/11 64비트 PC가 필요합니다."
    Abort
  ${EndIf}
FunctionEnd
Section "설치"
  SetRegView 64
  SetShellVarContext all
  SetOutPath "$INSTDIR"
  File /r "${PAYLOAD}/*"
  nsExec::ExecToStack '"$SYSDIR\netsh.exe" advfirewall firewall delete rule name="Moa Messages Local Sync"'
  Pop $0
  Pop $1
  nsExec::ExecToStack '"$SYSDIR\netsh.exe" advfirewall firewall add rule name="Moa Messages Local Sync" dir=in action=allow program="$INSTDIR\runtime\node.exe" protocol=TCP localport=44589 profile=any remoteip=localsubnet'
  Pop $0
  Pop $1
  ${If} $0 != 0
    MessageBox MB_ICONEXCLAMATION "방화벽 연결 설정을 완료하지 못했습니다. PC 앱은 사용할 수 있으나 갤럭시 연결에는 Windows 방화벽의 로컬 네트워크 허용이 필요합니다."
  ${EndIf}
  CreateShortcut "$DESKTOP\모아 메시지.lnk" "$INSTDIR\MoaMessages.exe"
  CreateDirectory "$SMPROGRAMS\모아 메시지"
  CreateShortcut "$SMPROGRAMS\모아 메시지\모아 메시지.lnk" "$INSTDIR\MoaMessages.exe"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\MoaMessages" "DisplayName" "모아 메시지"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\MoaMessages" "DisplayVersion" "0.2.0"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\MoaMessages" "UninstallString" '$\"$INSTDIR\Uninstall.exe$\"'
  WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\MoaMessages" "NoModify" 1
  WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\MoaMessages" "NoRepair" 1
SectionEnd
Section "Uninstall"
  SetRegView 64
  SetShellVarContext all
  MessageBox MB_OKCANCEL "실행 중인 모아 메시지 창에서 ‘PC 앱 완전히 종료’를 누른 뒤 제거해 주세요. 개인 메시지는 각 Windows 계정의 저장 폴더에 남습니다." IDOK proceed
  Abort
  proceed:
  nsExec::ExecToStack '"$SYSDIR\netsh.exe" advfirewall firewall delete rule name="Moa Messages Local Sync"'
  Pop $0
  Pop $1
  Delete "$DESKTOP\모아 메시지.lnk"
  RMDir /r "$SMPROGRAMS\모아 메시지"
  DeleteRegKey HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\MoaMessages"
  RMDir /r "$INSTDIR"
SectionEnd
