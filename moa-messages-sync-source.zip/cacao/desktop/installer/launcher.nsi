Unicode true
Name "모아 메시지"
OutFile "${OUT}"
RequestExecutionLevel user
SilentInstall silent
AutoCloseWindow true
Section
  SetOutPath "$EXEDIR"
  nsExec::Exec '"$EXEDIR\runtime\node.exe" "$EXEDIR\desktop\server.mjs"'
  Pop $0
SectionEnd
