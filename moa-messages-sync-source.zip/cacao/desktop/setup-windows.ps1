param([Parameter(Mandatory=$true)][string]$DataDir)
$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Force -Path $DataDir | Out-Null
$account = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
& icacls.exe $DataDir /inheritance:r /grant:r "${account}:(OI)(CI)F" | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Data directory protection failed' }
$secretFile = Join-Path $DataDir 'secret.dpapi'
if (!(Test-Path $secretFile)) {
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    $bytes = New-Object byte[] 32; $rng.GetBytes($bytes)
    $key = -join ($bytes | ForEach-Object { $_.ToString('x2') })
    $rng.GetBytes($bytes)
    $password = -join ($bytes | ForEach-Object { $_.ToString('x2') })
    @{ secret=$key; password=$password } | ConvertTo-Json -Compress | ConvertTo-SecureString -AsPlainText -Force | ConvertFrom-SecureString | Set-Content -Encoding UTF8 $secretFile
    $rng.Dispose()
}
$secure = (Get-Content $secretFile -Raw).Trim() | ConvertTo-SecureString
$settings = (New-Object System.Management.Automation.PSCredential('x',$secure)).GetNetworkCredential().Password | ConvertFrom-Json
$pfx = Join-Path $DataDir 'identity.pfx'
$cer = Join-Path $DataDir 'identity.cer'
$ips = @(Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -ne '127.0.0.1' -and $_.AddressState -eq 'Preferred' } | Select-Object -ExpandProperty IPAddress)
$refresh = !(Test-Path $pfx) -or !(Test-Path $cer)
if (!$refresh) {
    $existing = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($cer)
    $sanText = ($existing.Extensions | Where-Object { $_.Oid.Value -eq '2.5.29.17' }).Format($false)
    if ($existing.NotAfter -lt (Get-Date).AddDays(7)) { $refresh = $true }
    foreach ($ip in $ips) { if ($sanText -notmatch ('(?<![0-9.])' + [regex]::Escape($ip) + '(?![0-9.])')) { $refresh = $true } }
    $existing.Dispose()
}
if ($refresh) {
    $san = '2.5.29.17={text}DNS=localhost&IPAddress=127.0.0.1'
    foreach ($ip in $ips) { $san += "&IPAddress=$ip" }
    $cert = New-SelfSignedCertificate -Type Custom -KeyUsage DigitalSignature,KeyEncipherment -KeySpec KeyExchange -Subject 'CN=Moa Messages Local Sync' -CertStoreLocation Cert:\CurrentUser\My -KeyAlgorithm RSA -KeyLength 2048 -HashAlgorithm SHA256 -KeyExportPolicy Exportable -NotAfter (Get-Date).AddYears(3) -TextExtension @($san,'2.5.29.37={text}1.3.6.1.5.5.7.3.1')
    try {
        Export-PfxCertificate -Cert $cert -FilePath $pfx -CryptoAlgorithmOption AES256_SHA256 -Password (ConvertTo-SecureString $settings.password -AsPlainText -Force) | Out-Null
        Export-Certificate -Cert $cert -FilePath $cer | Out-Null
    } finally { Remove-Item "Cert:\CurrentUser\My\$($cert.Thumbprint)" }
}
