import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,readFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import http from 'node:http';
import {once} from 'node:events';
import {RelayStore} from '../store.mjs';
import {encryptMessage,decryptMessage,deriveToken} from '../crypto.mjs';
import {createHandler} from '../server.mjs';
const secret='a'.repeat(64),id='b'.repeat(64),message={id,source:'KAKAO',sender:'영희',conversation:'업무방',body:'내일 오후 3시에 만나요',receivedAt:1700000000000};
function fixture(){const dir=mkdtempSync(path.join(tmpdir(),'moa-test-'));const file=path.join(dir,'relay.sqlite');const store=new RelayStore(file);return {store,file,close:()=>{store.close();rmSync(dir,{recursive:true,force:true});}};}
test('AES-GCM roundtrip, wrong key and identity substitution rejection',()=>{
 const item=encryptMessage(message,secret);assert.deepEqual(decryptMessage(item,secret),message);
 assert.throws(()=>decryptMessage(item,'c'.repeat(64)));assert.throws(()=>decryptMessage({...item,id:'d'.repeat(64)},secret));
 const bytes=Buffer.from(item.ciphertext,'base64');bytes[0]^=1;assert.throws(()=>decryptMessage({...item,ciphertext:bytes.toString('base64')},secret));
});
test('Node/Android fixture uses the same authentication derivation and plaintext',()=>{
 const v=JSON.parse(readFileSync(new URL('../../app/src/test/resources/sync-vector.json',import.meta.url)));
 assert.equal(deriveToken(v.secret),v.token);assert.deepEqual(decryptMessage(v.item,v.secret),v.message);
});
test('retries cannot overwrite original or regress checked state; deletion persists',()=>{
 const f=fixture();try{
  const item=encryptMessage(message,secret);f.store.merge([item,item]);assert.equal(f.store.changes().items.length,1);
  f.store.merge([{...item,checked:true}]);f.store.merge([encryptMessage({...message,body:'changed'},secret)]);
  let row=f.store.changes().items[0];assert.equal(row.checked,true);assert.equal(decryptMessage(row,secret).body,message.body);
  f.store.merge([{id,deleted:true,checked:false}]);f.store.merge([item]);row=f.store.changes().items[0];assert.equal(row.deleted,true);assert.equal(row.ciphertext,null);
  assert.equal(readFileSync(f.file).includes(Buffer.from(message.body)),false);
  const reopened=new RelayStore(f.file);assert.equal(reopened.changes().items[0].deleted,true);assert.equal(reopened.instance,f.store.instance);reopened.close();
 }finally{f.close();}
});
test('change pagination includes later updates without advancing over unseen records',()=>{
 const f=fixture();try{const item=encryptMessage(message,secret);for(let batch=0;batch<3;batch++)f.store.merge(Array.from({length:80},(_,i)=>({...item,id:(batch*80+i).toString(16).padStart(64,'0')})));
 const first=f.store.changes(0);assert.equal(first.items.length,200);assert.equal(first.more,true);
 const second=f.store.changes(first.cursor);assert.equal(second.items.length,40);assert.equal(second.more,false);
 f.store.merge([{...item,id:first.items[0].id,checked:true}]);assert.equal(f.store.changes(second.cursor).items.length,1);
 }finally{f.close();}
});
test('invalid batch is atomic and plaintext fields are rejected',()=>{
 const f=fixture();try{const item=encryptMessage(message,secret);assert.throws(()=>f.store.merge([item,{id:'invalid'}]));assert.equal(f.store.changes().items.length,0);assert.throws(()=>f.store.merge([{...item,body:message.body}]));assert.throws(()=>f.store.changes(-1));}finally{f.close();}
});
test('authenticated API syncs a message, rejects cross-origin requests and bad credentials',async()=>{
 const f=fixture();const server=http.createServer(createHandler({store:f.store,secret}));server.listen(0,'127.0.0.1');await once(server,'listening');
 const base=`http://127.0.0.1:${server.address().port}`,headers={Authorization:'Bearer '+deriveToken(secret),'Content-Type':'application/json'};
 try{
  assert.equal((await fetch(base+'/api/changes')).status,401);
  assert.equal((await fetch(base+'/api/changes',{headers:{...headers,Origin:'https://evil.example'}})).status,403);
  assert.equal((await fetch(base+'/api/messages',{method:'POST',headers,body:JSON.stringify({items:[encryptMessage(message,secret)]})})).status,200);
  const page=await(await fetch(base+'/api/changes?after=0',{headers})).json();assert.equal(decryptMessage(page.items[0],secret).sender,'영희');
  assert.equal((await fetch(base+'/api/pair',{headers})).status,404);
 }finally{server.close();await once(server,'close');f.close();}
});
test('desktop bootstrap is one-time and rejects forged Host headers',async()=>{
 const f=fixture(),server=http.createServer();server.listen(0,'127.0.0.1');await once(server,'listening');const port=server.address().port;
 server.on('request',createHandler({store:f.store,secret,desktop:true,port,launchCode:'one-time-code'}));
 try{const url=`http://127.0.0.1:${port}/api/unlock`,options={method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code:'one-time-code'})};
  const forgedStatus=await new Promise((resolve,reject)=>{const request=http.request(url,{method:'POST',headers:{'Content-Type':'application/json',Host:'evil.example'}},response=>{response.resume();resolve(response.statusCode);});request.on('error',reject);request.end(options.body);});
  assert.equal(forgedStatus,403);
  assert.equal((await(await fetch(url,options)).json()).secret,secret);assert.equal((await fetch(url,options)).status,401);
 }finally{server.close();await once(server,'close');f.close();}
});
test('HTTPS transport accepts only the explicitly trusted PC certificate and syncs encrypted data',async()=>{
 const {execFileSync}=await import('node:child_process');const https=await import('node:https');
 const dir=mkdtempSync(path.join(tmpdir(),'moa-tls-'));let relay;
 try{
  execFileSync('openssl',['req','-x509','-newkey','rsa:2048','-nodes','-keyout',path.join(dir,'key.pem'),'-out',path.join(dir,'cert.pem'),'-days','1','-subj','/CN=localhost','-addext','subjectAltName=IP:127.0.0.1,DNS:localhost'],{stdio:'ignore'});
  execFileSync('openssl',['pkcs12','-export','-inkey',path.join(dir,'key.pem'),'-in',path.join(dir,'cert.pem'),'-out',path.join(dir,'identity.pfx'),'-passout','pass:fixture-password'],{stdio:'ignore'});
  const store=new RelayStore(path.join(dir,'relay.sqlite'));store.merge([encryptMessage(message,secret)]);
  relay=https.createServer({pfx:readFileSync(path.join(dir,'identity.pfx')),passphrase:'fixture-password',minVersion:'TLSv1.2'},createHandler({store,secret}));relay.listen(0,'127.0.0.1');await once(relay,'listening');
  const request=ca=>new Promise((resolve,reject)=>{const req=https.get(`https://127.0.0.1:${relay.address().port}/api/changes`,{...(ca?{ca}:{}),headers:{Authorization:'Bearer '+deriveToken(secret)}},res=>{let text='';res.on('data',chunk=>text+=chunk);res.on('end',()=>resolve(JSON.parse(text)));});req.on('error',reject);});
  await assert.rejects(request(undefined));
  const response=await request(readFileSync(path.join(dir,'cert.pem')));assert.equal(decryptMessage(response.items[0],secret).body,message.body);
  relay.close();await once(relay,'close');relay=null;store.close();
 }finally{if(relay){relay.closeAllConnections();relay.close();}rmSync(dir,{recursive:true,force:true});}
});
