import http from 'node:http';
import https from 'node:https';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import {randomBytes, timingSafeEqual, X509Certificate} from 'node:crypto';
import {spawn, execFileSync} from 'node:child_process';
import QRCode from 'qrcode';
import {RelayStore} from './store.mjs';
import {deriveToken} from './crypto.mjs';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
export function createHandler({store,secret,pairing,launchCode,launchBox={code:launchCode},onOpen=null,onQuit=()=>{},desktop=false,port=44588}) {
 const token=deriveToken(secret), failures=new Map();
 const respond=(res,code,data)=>{res.writeHead(code,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(data));};
 return async(req,res)=>{
  res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('Referrer-Policy','no-referrer');
  res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
  const host=req.headers.host, origin=req.headers.origin;
  if(desktop && ![`127.0.0.1:${port}`,`localhost:${port}`].includes(host)) return respond(res,403,{error:'허용되지 않은 주소입니다.'});
  if(origin && origin!==`${desktop?'http':'https'}://${host}`) return respond(res,403,{error:'다른 사이트의 요청은 허용되지 않습니다.'});
  const url=new URL(req.url,'http://localhost');
  if(desktop && req.method==='GET' && ['/','/app.mjs','/style.css'].includes(url.pathname)) {
   const name={'/':'index.html','/app.mjs':'app.mjs','/style.css':'style.css'}[url.pathname];
   res.setHeader('Content-Type',name.endsWith('html')?'text/html; charset=utf-8':name.endsWith('css')?'text/css':'text/javascript');
   return res.end(fs.readFileSync(path.join(root,'web',name)));
  }
  let body;
  try {
   if(req.method==='POST') {
    if(!req.headers['content-type']?.startsWith('application/json')) return respond(res,415,{error:'JSON 요청이 필요합니다.'});
    let size=0;const chunks=[];
    for await(const chunk of req){size+=chunk.length;if(size>(url.pathname==='/api/messages'?16*1024*1024:16384)){respond(res,413,{error:'요청이 너무 큽니다.'});req.destroy();return;}chunks.push(chunk);}
    body=JSON.parse(Buffer.concat(chunks).toString()||'{}');
   }
  }catch{ return respond(res,400,{error:'요청 형식을 확인해 주세요.'}); }
  if(desktop && req.method==='POST' && url.pathname==='/api/unlock' && launchBox.code && body.code===launchBox.code) {
   launchBox.code=null;return respond(res,200,{secret});
  }
  const address=req.socket.remoteAddress, now=Date.now(), fail=failures.get(address);
  if(fail && now-fail.time<60000 && fail.count>=10) return respond(res,429,{error:'잠시 후 다시 연결해 주세요.'});
  const got=Buffer.from(req.headers.authorization||''),expected=Buffer.from('Bearer '+token);
  if(got.length!==expected.length || !timingSafeEqual(got,expected)) {
   if(failures.size>1000) failures.clear();
   failures.set(address,{time:now,count:fail&&now-fail.time<60000?fail.count+1:1});
   return respond(res,401,{error:'연결 정보를 확인해 주세요.'});
  }
  try {
   if(req.method==='GET' && url.pathname==='/api/changes') return respond(res,200,store.changes(Number(url.searchParams.get('after')||0)));
   if(req.method==='POST' && url.pathname==='/api/messages'){store.merge(body.items);return respond(res,200,{ok:true});}
   if(desktop && req.method==='POST' && url.pathname==='/api/open' && onOpen){onOpen();return respond(res,200,{ok:true});}
   if(desktop && req.method==='GET' && url.pathname==='/api/pair'){
    const uri='moainbox://pair?data='+Buffer.from(JSON.stringify(pairing)).toString('base64url');
    return respond(res,200,{uri,svg:await QRCode.toString(uri,{type:'svg',errorCorrectionLevel:'M'}),urls:pairing.urls});
   }
   if(desktop && req.method==='POST' && url.pathname==='/api/quit'){respond(res,200,{ok:true});setTimeout(onQuit,200);return;}
   respond(res,404,{error:'요청을 찾을 수 없습니다.'});
  }catch{respond(res,400,{error:'동기화 자료를 처리하지 못했습니다. 형식과 저장 공간을 확인해 주세요.'});}
 };
}
export async function startDesktop({dataDir,openBrowser=true}={}) {
 if(process.platform!=='win32') throw Error('Windows 설치 프로그램으로 실행해 주세요.');
 dataDir ||= path.join(process.env.LOCALAPPDATA,'MoaMessages');
 const ps=path.join(root,'desktop','setup-windows.ps1');
 execFileSync('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',ps,'-DataDir',dataDir],{windowsHide:true,stdio:'pipe'});
 const encoded=fs.readFileSync(path.join(dataDir,'secret.dpapi'),'utf8').trim();
 // DPAPI decrypts only in the Windows account that created the installation data.
 const secrets=JSON.parse(execFileSync('powershell.exe',['-NoProfile','-NonInteractive','-Command',
  '$s=ConvertTo-SecureString $env:MOA_DPAPI; (New-Object System.Management.Automation.PSCredential("x",$s)).GetNetworkCredential().Password'],
  {windowsHide:true,encoding:'utf8',env:{...process.env,MOA_DPAPI:encoded}}));
 try {
  const existing=await fetch('http://127.0.0.1:44588/api/open',{method:'POST',headers:{Authorization:'Bearer '+deriveToken(secrets.secret),'Content-Type':'application/json'},body:'{}',signal:AbortSignal.timeout(1500)});
  if(existing.ok) return {alreadyRunning:true};
 }catch{}
 const pfx=fs.readFileSync(path.join(dataDir,'identity.pfx'));
 const cert=new X509Certificate(fs.readFileSync(path.join(dataDir,'identity.cer')));
 const fingerprint=cert.fingerprint256.replaceAll(':','').toLowerCase();
 const urls=Object.values(os.networkInterfaces()).flat().filter(x=>x.family==='IPv4'&&!x.internal&&cert.checkIP(x.address)).map(x=>`https://${x.address}:44589`);
 const pairing={version:1,urls,secret:secrets.secret,fingerprint};
 const store=new RelayStore(path.join(dataDir,'messages.sqlite'));
 const lan=https.createServer({pfx,passphrase:secrets.password,minVersion:'TLSv1.2'},createHandler({store,secret:secrets.secret}));
 const launchBox={code:null};
 const openWindow=()=>{
  launchBox.code=randomBytes(24).toString('hex');
  const url=`http://127.0.0.1:44588/#launch=${launchBox.code}`;
  const edge=[process.env['ProgramFiles(x86)'],process.env.ProgramFiles].filter(Boolean).map(p=>path.join(p,'Microsoft','Edge','Application','msedge.exe')).find(fs.existsSync);
  if(edge) spawn(edge,[`--app=${url}`],{windowsHide:true,detached:true,stdio:'ignore'}).unref();
  else spawn('explorer.exe',[url],{windowsHide:true,stdio:'ignore'}).unref();
 };
 const local=http.createServer(createHandler({store,secret:secrets.secret,pairing,launchBox,onOpen:openWindow,desktop:true,onQuit:()=>{lan.close();local.close();store.close();process.exit(0);}}));
 lan.requestTimeout=15000;local.requestTimeout=15000;lan.maxHeadersCount=32;local.maxHeadersCount=32;lan.maxConnections=16;local.maxConnections=16;
 await new Promise((ok,bad)=>{lan.once('error',bad);lan.listen(44589,'0.0.0.0',ok);});
 await new Promise((ok,bad)=>{local.once('error',bad);local.listen(44588,'127.0.0.1',ok);});
 if(openBrowser)openWindow();
 return {local,lan,store};
}
if(process.argv[1]===fileURLToPath(import.meta.url)) {
 startDesktop().catch(()=>{
  if(process.platform==='win32')execFileSync('powershell.exe',['-NoProfile','-Command','Add-Type -AssemblyName PresentationFramework; [System.Windows.MessageBox]::Show("앱을 시작하지 못했습니다. 이미 실행 중인 모아 메시지 창을 확인하거나 PC를 재시작해 주세요.","모아 메시지")'],{windowsHide:true,stdio:'ignore'});
  process.exitCode=1;
 });
}
