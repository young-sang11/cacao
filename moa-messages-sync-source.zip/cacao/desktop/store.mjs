import {randomUUID} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
const idPattern=/^[a-f0-9]{64}$/;
export class RelayStore {
 constructor(path) {
  this.db=new DatabaseSync(path);
  this.db.exec(`PRAGMA secure_delete=ON; PRAGMA journal_mode=DELETE;
   CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY,iv TEXT,ciphertext TEXT,checked INTEGER NOT NULL,deleted INTEGER NOT NULL,rev INTEGER NOT NULL);
   CREATE TABLE IF NOT EXISTS identity(id TEXT NOT NULL); CREATE TABLE IF NOT EXISTS meta(revision INTEGER NOT NULL); INSERT INTO meta SELECT 0 WHERE NOT EXISTS(SELECT 1 FROM meta);`);
  if(!this.db.prepare('SELECT id FROM identity').get()) this.db.prepare('INSERT INTO identity VALUES(?)').run(randomUUID());
  this.instance=this.db.prepare('SELECT id FROM identity').get().id;
 }
 validate(item) {
  if(item && Object.keys(item).some(k=>!['id','iv','ciphertext','checked','deleted'].includes(k))) throw Error('Unexpected fields');
  if(!item || !idPattern.test(item.id) || typeof item.checked!=='boolean' || typeof item.deleted!=='boolean') throw Error('Invalid message');
  if(!item.deleted && (!/^[A-Za-z0-9+/]{16}$/.test(item.iv||'') || typeof item.ciphertext!=='string' || item.ciphertext.length>131072 || !/^[A-Za-z0-9+/]+={0,2}$/.test(item.ciphertext) || Buffer.from(item.ciphertext,'base64').length<16)) throw Error('Invalid encrypted payload');
 }
 merge(items) {
  if(!Array.isArray(items) || items.length>100) throw Error('Invalid batch');
  items.forEach(x=>this.validate(x));
  this.db.exec('BEGIN IMMEDIATE');
  try {
   for(const item of items) {
    const prev=this.db.prepare('SELECT * FROM messages WHERE id=?').get(item.id);
    if(prev && (!item.checked || prev.checked) && (!item.deleted || prev.deleted)) continue;
    if(!prev && this.db.prepare('SELECT COUNT(*) AS n FROM messages').get().n>=10000) throw Error('Message capacity reached');
    this.db.exec('UPDATE meta SET revision=revision+1');
    const rev=this.db.prepare('SELECT revision FROM meta').get().revision;
    const deleted=!!(item.deleted||prev?.deleted), checked=!!(item.checked||prev?.checked);
    this.db.prepare('INSERT OR REPLACE INTO messages VALUES(?,?,?,?,?,?)').run(item.id,deleted?null:(prev?.iv||item.iv),deleted?null:(prev?.ciphertext||item.ciphertext),+checked,+deleted,rev);
   }
   this.db.exec('COMMIT');
  } catch(e) { this.db.exec('ROLLBACK'); throw e; }
 }
 changes(after=0) {
  if(!Number.isSafeInteger(after)||after<0) throw Error('Invalid cursor');
  const rows=this.db.prepare('SELECT * FROM messages WHERE rev>? ORDER BY rev LIMIT 201').all(after),more=rows.length>200;
  const items=rows.slice(0,200).map(r=>({...r,checked:!!r.checked,deleted:!!r.deleted}));
  return {items,cursor:items.at(-1)?.rev??after,more,instance:this.instance};
 }
 close(){this.db.close();}
}
