# 동기화 v1

사용자 승인 후 공유 연결키(암호학적 무작위 32바이트, hex 64자)로 연결합니다.
암호화 키 = SHA-256(UTF-8 `moa:encryption:v1:` + 연결키), 인증 토큰 = hex SHA-256(`moa:auth:v1:` + 연결키).
키 재사용 용도를 분리합니다. AES-256-GCM, 무작위 12바이트 IV, AAD `moa:v1:` + 원본 ID, 암호문 끝 16바이트 인증 태그.
평문은 UTF-8 JSON {id,source,conversation,sender,body,receivedAt}. 원본 ID는 기존 앱 ID를 유지합니다.
서버 DB에는 ID, 암호문, IV, 확인 여부, 삭제 표식, 증가 revision만 저장합니다.
PC 연결키는 Windows DPAPI, 갤럭시 연결키는 Android Keystore로 보호합니다.

POST /api/messages: {items:[{id,iv,ciphertext,checked,deleted}]} 최대 100개.
기존 원문은 덮어쓰지 않으며 checked/deleted는 OR 병합. 삭제는 영구 tombstone으로 오프라인 기기의 재삽입 방지.
삭제된 원문의 암호문은 서버 DB에서 제거합니다. 메시지 복구는 지원하지 않습니다.
GET /api/changes?after=N: revision 순 최대 200개. {items,cursor,more}.
클라이언트는 복호화/로컬 DB 적용 성공 후에만 cursor를 갱신합니다.
각 ID를 AAD로 검증하며 인증 태그/원본 ID 불일치 시 적용하지 않습니다.
중단된 업로드는 재시도해도 원문/확인 상태가 후퇴하지 않습니다.
인증: Authorization: Bearer <인증 토큰>. 모든 LAN 통신은 TLS + PC 인증서 SHA-256 지문 고정.

PC가 켜져 있고 앱이 실행 중이어야 동기화됩니다. 기본 구성은 같은 사설 네트워크용입니다.
서로 다른 인터넷 회선에서의 자동 연결/공용 중계 서버/계정 복구는 현재 제공하지 않습니다.
외부에서 사용할 때는 별도로 관리되는 인증된 VPN/HTTPS 서버가 필요합니다. 공유기 포트 개방은 자동으로 하지 않습니다.
Windows는 기존 카카오톡을 자동 수집하지 않습니다. 갤럭시 알림을 동기화하거나 텍스트를 명시적으로 가져옵니다.
