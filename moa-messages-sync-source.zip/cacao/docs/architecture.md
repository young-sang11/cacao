# 1단계 구조와 외부 연동 범위

- `KakaoNotificationListener`: OS가 전달한 알림 중 카카오톡만 허용. 동의와 기기 잠금 설정을 확인.
- `NotificationExtractor`: MessagingStyle 원문/발신자/시간 추출, 일반 텍스트 대체, 요약 및 민감 문구 제외.
- `MessageRules`: 대화·발신자·내용·메시지 시간을 길이 구분 후 SHA-256으로 해시해 ID 생성.
- `MessageStore`: 앱 전용 SQLite DB. 순서가 보장되는 작업 큐와 동의 세대로 중지/삭제 후 대기 알림 재삽입 방지.
- `MainActivity`: Compose 수신함, 기기 자격 증명 인증, 다중 선택, 확인 상태 및 복사.

원본 메시지 ID는 영구 보존합니다. 향후 추천 답장은 별도 테이블의 `original_message_id` 외래 키로 연결해야 합니다.
답장 추천 화면은 해당 ID의 출처·발신자·받은 시간·원문을 다시 읽어 표시하고 다른 대화의 답장을 재사용하지 않아야 합니다.
현재는 AI 답장/전송 기능 및 해당 테이블을 구현하지 않았습니다.

## 공식 Android API 기반 기능

- [NotificationListenerService](https://developer.android.com/reference/android/service/notification/NotificationListenerService): 사용자 허용에 따른 알림 수신
- [NotificationCompat.MessagingStyle](https://developer.android.com/reference/androidx/core/app/NotificationCompat.MessagingStyle): 알림이 제공한 개별 메시지 해석
- [Notification.contentIntent](https://developer.android.com/reference/android/app/Notification#contentIntent): 사용자가 원본 열기 버튼을 누를 때 원본 알림의 앱 제공 동작 실행
- [KeyguardManager](https://developer.android.com/reference/android/app/KeyguardManager): 기기 자격 증명 확인

카카오톡 내부 DB, 비공개 API, 접근성 화면 자동화, 특정 대화방 비공식 URI는 사용하지 않습니다.
원본 알림 동작이 없으면 설치된 카카오톡 앱의 실행 Intent로 대체합니다. 특정 대화방 이동을 보장하지 않습니다.
ChatGPT 공유/특정 대화 자동 입력과 PC 카카오톡 수집 지원 여부는 해당 단계에서 공식 기능을 확인하고 구현해야 합니다.
