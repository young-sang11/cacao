# 1단계 검증 결과

## 실제 실행한 검사

- `scripts/test-core.sh`: 16개 검사 통과.
- `./gradlew --no-daemon assembleDebug testDebugUnitTest lintDebug --console=plain`: BUILD SUCCESSFUL.
- Robolectric / Compose 테스트: 6개 실행, 실패 0, 오류 0, 건너뜀 0.
  - 한국어 잠금 화면 실제 Compose 렌더링, 잠금 해제 전 수신함 비표시, 화면 캡처 차단 설정
  - 다른 앱/요약 알림/민감 문구 제외
  - 일반 알림 원문·발신자·시간 보존 및 안정적인 ID
  - MessagingStyle 대화 이름·발신자·반복 문구의 시간별 구분
  - SQLite 중복 제거·확인 상태 유지·저장소 재생성 후 자료 유지
  - 수집 중지·전체 삭제 후 대기 메시지 삽입 차단
- `bash scripts/setup-cloud.sh` 전체 반복 실행: BUILD SUCCESSFUL, 기존 빌드/테스트 결과 재사용 확인.
- Gradle Wrapper: 공식 Gradle 8.9 배포 다운로드 및 고정 SHA-256 검증 후 빌드 성공.
- `apksigner verify --verbose`: 유효한 APK v2 개발용 서명 확인.
- `aapt dump permissions`: 인터넷·SMS·외부 저장소 권한 없음. AndroidX 내부용 signature 권한만 선언.
- `adb devices`: 연결된 Android 기기 없음. 확인을 위해 시작한 ADB 서버는 종료함.

## 린트

오류 0건, 경고 2건.

- `ApplySharedPref`: 수집 동의/중지 설정을 즉시 저장하기 위해 동기 `commit()` 사용. 작은 설정 쓰기지만 UI 스레드 I/O 경고가 있음.
- `MissingApplicationIcon`: 전용 앱 아이콘 미제공. 개발용 APK의 기본 아이콘 사용.

## 아직 검증하지 않은 항목

실제 갤럭시 설치와 카카오톡 수신, One UI 절전/백그라운드 동작, 제조사별 잠금 인증 화면,
실제 알림에서의 대화방 열기, TalkBack/글꼴 확대 실기기 사용성은 미검증입니다.
JVM에서의 Android 환경 재현 테스트 통과가 실제 카카오톡 호환성을 보장하지 않습니다.
[기기 검증 절차](device-test.md)를 실행한 뒤 결과를 별도로 기록해야 합니다.

이 APK는 개발용 서명이며 정식 출시용 설치 파일이 아닙니다.
SMS·첨부파일·ChatGPT·AI 답장·일정·Windows 프로그램은 후속 단계입니다.

## 재현 도구

JDK 17.0.13, Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21,
Android SDK/빌드 도구 35, Robolectric 4.14.1(API 34 재현).
소스와 빌드 설정은 저장소에 있으며 설치 도구는 `/workspace/.tools`에 있습니다.
클라우드 `install_script`와 `start_skill`을 설정 초안에 저장했습니다.
초안 저장은 환경 게시나 새 작업에서의 복원 검증을 의미하지 않습니다.
