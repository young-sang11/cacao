const $=id=>document.getElementById(id), encoder=new TextEncoder(),decoder=new TextDecoder();
let secret=null,token=null,key=null,cursor=0,items=new Map(),selected=new Set(),busy=false,epoch=0,detail=null,qrURL=null,serverInstance=null;
const hex=bytes=>Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('');
const sha=text=>crypto.subtle.digest('SHA-256',encoder.encode(text));
const b64=buffer=>btoa(String.fromCharCode(...new Uint8Array(buffer)));
const unb64=text=>Uint8Array.from(atob(text),c=>c.charCodeAt(0));
function notice(text){$('notice').textContent=text;$('notice').style.display='block';setTimeout(()=>$('notice').style.display='none',5000);}
function lock(){epoch++;secret=token=key=null;cursor=0;items.clear();selected.clear();detail=null;$('secret').value='';$('query').value='';$('body').value='';$('sender').value='';serverInstance=null;$('messages').replaceChildren();$('detail-body').textContent='';$('detail-title').textContent='';$('detail-meta').textContent='';$('pairtext').value='';$('qr').removeAttribute('src');if(qrURL)URL.revokeObjectURL(qrURL);document.querySelectorAll('dialog').forEach(d=>d.close());$('inbox').hidden=true;$('locked').hidden=false;}
async function unlock(value){
 if(!/^[a-f0-9]{64}$/.test(value))throw Error('64자리 연결키를 확인해 주세요.');
 const generation=++epoch;
 const nextToken=hex(await sha('moa:auth:v1:'+value));
 const nextKey=await crypto.subtle.importKey('raw',await sha('moa:encryption:v1:'+value),'AES-GCM',false,['encrypt','decrypt']);
 if(generation!==epoch)return;
 secret=value;token=nextToken;key=nextKey;cursor=0;items.clear();$('secret').value='';
 $('locked').hidden=true;$('inbox').hidden=false;await sync();
}
async function api(route,body){const response=await fetch(route,{method:body?'POST':'GET',headers:{Authorization:'Bearer '+token,...(body?{'Content-Type':'application/json'}:{})},body:body?JSON.stringify(body):undefined,cache:'no-store'});const result=await response.json();if(!response.ok)throw Error(result.error||'연결하지 못했습니다.');return result;}
async function decode(item,activeKey){const raw=await crypto.subtle.decrypt({name:'AES-GCM',iv:unb64(item.iv),additionalData:encoder.encode('moa:v1:'+item.id)},activeKey,unb64(item.ciphertext));const message=JSON.parse(decoder.decode(raw));if(message.id!==item.id)throw Error('원본 메시지 확인에 실패했습니다.');return {...message,...item};}
async function sync(){
 if(!secret||busy)return;busy=true;const generation=epoch,activeKey=key;
 try{let more=true;while(more){const page=await api('/api/changes?after='+cursor);if(generation!==epoch)return;if(serverInstance&&serverInstance!==page.instance){cursor=0;items.clear();selected.clear();serverInstance=page.instance;continue;}serverInstance=page.instance;const pending=[];
  for(const item of page.items)pending.push(item.deleted?item:await decode(item,activeKey));
  if(generation!==epoch)return;
  for(const item of pending){if(item.deleted){items.delete(item.id);selected.delete(item.id);}else items.set(item.id,item);}
  cursor=page.cursor;more=page.more;
 }if(generation===epoch){render();$('status').textContent='동기화 완료 · '+new Date().toLocaleTimeString('ko-KR');}}
 catch(e){if(generation===epoch)$('status').textContent='동기화 실패: 연결 정보 또는 PC 저장 공간을 확인해 주세요.';}
 finally{busy=false;}
}
const when=m=>new Date(m.receivedAt).toLocaleString('ko-KR');
const source=m=>m.source==='IMPORT'?'직접 가져온 내용':'카카오톡';
function add(parent,tag,text,cls){const el=document.createElement(tag);el.textContent=text;if(cls)el.className=cls;parent.append(el);return el;}
function render(){
 $('counts').textContent=`미확인 ${[...items.values()].filter(m=>!m.checked).length}개 · 전체 ${items.size}개`;
 const query=$('query').value.trim().toLowerCase();const list=[...items.values()].filter(m=>(!$('unread').checked||!m.checked)&&[m.sender,m.body,m.conversation,when(m)].join(' ').toLowerCase().includes(query));
 list.sort((a,b)=>$('sort').value==='person'?a.sender.localeCompare(b.sender,'ko')||b.receivedAt-a.receivedAt:b.receivedAt-a.receivedAt);
 $('messages').replaceChildren();$('empty').hidden=list.length>0;$('selection').textContent=`${selected.size}개 선택됨`;
 for(const m of list){const card=add($('messages'),'article','',''+(m.checked?'checked':''));const label=add(card,'label','');const box=document.createElement('input');box.type='checkbox';box.checked=selected.has(m.id);box.setAttribute('aria-label',`${m.sender}의 ${when(m)} 메시지 선택`);box.onchange=()=>{box.checked?selected.add(m.id):selected.delete(m.id);$('selection').textContent=`${selected.size}개 선택됨`;};label.append(box,document.createTextNode(`${source(m)} · ${m.checked?'확인 완료':'미확인'}`));add(card,'h3',m.sender);add(card,'p',`${m.conversation} · ${when(m)}`,'meta');add(card,'p',m.body,'preview');const open=add(card,'button','원문 전체 보기');open.onclick=()=>{detail=m;$('detail-title').textContent=`${source(m)} · ${m.sender}`;$('detail-meta').textContent=`${m.conversation} · ${when(m)}`;$('detail-body').textContent=m.body;$('detail').showModal();mark([m.id]).catch(()=>notice('확인 상태를 저장하지 못했습니다.'));};}
}
const picked=()=>[...selected].map(id=>items.get(id)).filter(Boolean);
const format=m=>`[${source(m)}] ${m.conversation}\n보낸 사람: ${m.sender}\n받은 시간: ${when(m)}\n${m.body}`;
async function copy(messages){if(!messages.length)return notice('먼저 메시지를 선택해 주세요.');await navigator.clipboard.writeText(messages.map(format).join('\n\n'));notice('복사했습니다. 붙여넣기 전에 내용을 확인해 주세요.');}
async function upload(items){for(let i=0;i<items.length;i+=100)await api('/api/messages',{items:items.slice(i,i+100)});}
async function mark(ids){await upload(ids.map(id=>({id,iv:items.get(id)?.iv,ciphertext:items.get(id)?.ciphertext,checked:true,deleted:false})).filter(x=>x.id));await sync();}
$('lock').onclick=lock;$('unlock').onclick=()=>unlock($('secret').value.trim().toLowerCase()).catch(e=>notice(e.message));
$('sync').onclick=sync;for(const id of ['query','unread','sort'])$(id).addEventListener('input',render);
$('copy').onclick=()=>copy(picked()).catch(()=>notice('클립보드 복사를 허용해 주세요.'));
$('copy-detail').onclick=()=>copy(detail?[detail]:[]).catch(()=>notice('복사하지 못했습니다.'));
$('check').onclick=()=>mark([...selected]).catch(()=>notice('저장하지 못했습니다.'));
$('remove').onclick=async()=>{if(!selected.size)return notice('삭제할 메시지를 선택해 주세요.');if(!confirm('선택한 메시지를 삭제할까요? 연결된 갤럭시에서도 다음 동기화 때 삭제되며 복구할 수 없습니다. 카카오톡 원본은 그대로 유지됩니다.'))return;try{await upload([...selected].map(id=>({id,deleted:true,checked:false})));await sync();}catch{notice('삭제하지 못했습니다. 다시 시도해 주세요.');}};
$('purge').onclick=async()=>{if(!items.size)return notice('삭제할 자료가 없습니다.');if(!confirm('PC의 모든 메시지를 삭제할까요? 연결 기기도 다음 동기화에서 삭제됩니다. 카카오톡 원본은 유지되며 이 앱의 자료는 복구할 수 없습니다.'))return;try{await upload([...items.keys()].map(id=>({id,deleted:true,checked:false})));await sync();}catch{notice('일부 자료를 삭제하지 못했습니다. 다시 시도해 주세요.');}};
$('pair').onclick=async()=>{try{const p=await api('/api/pair');$('pairtext').value=p.uri;$('addresses').textContent=p.urls.length?'같은 Wi-Fi에서 연결해 주세요.':'사용할 수 있는 네트워크 주소가 없습니다. Wi-Fi 연결 후 앱을 다시 실행해 주세요.';if(qrURL)URL.revokeObjectURL(qrURL);qrURL=URL.createObjectURL(new Blob([p.svg],{type:'image/svg+xml'}));$('qr').src=qrURL;$('pairing').showModal();}catch{notice('연결 정보를 열지 못했습니다.');}};
$('copy-pair').onclick=()=>navigator.clipboard.writeText($('pairtext').value).then(()=>notice('내 갤럭시에만 전달해 주세요.'));
$('import').onclick=()=>$('importing').showModal();
$('save-import').onclick=async()=>{try{const body=$('body').value,sender=$('sender').value.trim()||'직접 가져오기';if(!body.trim())return notice('내용을 입력해 주세요.');const id=hex(await sha(crypto.randomUUID()));const m={id,source:'IMPORT',conversation:sender,sender,body,receivedAt:Date.now()};const iv=crypto.getRandomValues(new Uint8Array(12));const ciphertext=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:encoder.encode('moa:v1:'+id)},key,encoder.encode(JSON.stringify(m)));await api('/api/messages',{items:[{id,iv:b64(iv),ciphertext:b64(ciphertext),checked:false,deleted:false}]});$('body').value='';$('sender').value='';$('importing').close();await sync();}catch{notice('내용을 저장하지 못했습니다.');}};
$('quit').onclick=async()=>{if(confirm('PC 앱을 완전히 종료할까요? 다시 실행할 때까지 갤럭시 동기화가 중지됩니다.')){try{await api('/api/quit',{});}finally{lock();notice('앱을 종료했습니다. 이 창을 닫아 주세요.');}}};
for(const button of document.querySelectorAll('[data-close]'))button.onclick=()=>$(button.dataset.close).close();
const params=new URLSearchParams(location.hash.slice(1));history.replaceState(null,'',location.pathname);
if(params.has('launch'))fetch('/api/unlock',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code:params.get('launch')})}).then(r=>r.ok?r.json():Promise.reject()).then(data=>unlock(data.secret)).catch(()=>notice('PC 앱 아이콘을 다시 실행하거나 연결키로 열어 주세요.'));
setInterval(sync,5000);let idle=setTimeout(lock,5*60*1000);for(const name of ['pointerdown','keydown'])document.addEventListener(name,()=>{clearTimeout(idle);idle=setTimeout(lock,5*60*1000);});
